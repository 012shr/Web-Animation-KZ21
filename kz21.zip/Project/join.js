(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"join_atlas_1", frames: [[0,1202,1378,488],[0,0,940,1200],[942,0,916,500],[0,1692,993,354],[942,502,900,360]]},
		{name:"join_atlas_2", frames: [[1672,140,38,29],[1595,0,74,75],[1671,0,72,65],[1595,140,75,56],[1595,198,81,50],[1595,77,80,61],[902,580,529,306],[902,0,691,373],[0,362,900,241],[902,375,900,203],[0,0,900,360]]}
];


(lib.AnMovieClip = function(){
	this.actionFrames = [];
	this.ignorePause = false;
	this.gotoAndPlay = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndPlay.call(this,positionOrLabel);
	}
	this.play = function(){
		cjs.MovieClip.prototype.play.call(this);
	}
	this.gotoAndStop = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndStop.call(this,positionOrLabel);
	}
	this.stop = function(){
		cjs.MovieClip.prototype.stop.call(this);
	}
}).prototype = p = new cjs.MovieClip();
// symbols:



(lib.Bitmap17 = function() {
	this.initialize(ss["join_atlas_1"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap18 = function() {
	this.initialize(ss["join_atlas_1"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap20 = function() {
	this.initialize(ss["join_atlas_2"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap21 = function() {
	this.initialize(ss["join_atlas_2"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap23 = function() {
	this.initialize(ss["join_atlas_2"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap24 = function() {
	this.initialize(ss["join_atlas_2"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap25 = function() {
	this.initialize(ss["join_atlas_2"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap26 = function() {
	this.initialize(ss["join_atlas_2"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap27 = function() {
	this.initialize(ss["join_atlas_1"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap30 = function() {
	this.initialize(ss["join_atlas_2"]);
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap32 = function() {
	this.initialize(ss["join_atlas_2"]);
	this.gotoAndStop(7);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap33 = function() {
	this.initialize(ss["join_atlas_1"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap5 = function() {
	this.initialize(ss["join_atlas_2"]);
	this.gotoAndStop(8);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap6 = function() {
	this.initialize(ss["join_atlas_2"]);
	this.gotoAndStop(9);
}).prototype = p = new cjs.Sprite();



(lib.ChimmyStockPhoto = function() {
	this.initialize(img.ChimmyStockPhoto);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,2100,1500);


(lib.GrassDarken = function() {
	this.initialize(ss["join_atlas_1"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.SkyDarkend = function() {
	this.initialize(ss["join_atlas_2"]);
	this.gotoAndStop(10);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop, this.reversed));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.an_Video = function(options) {
	this.initialize();
	this._element = new $.an.Video(options);
	this._el = this._element.create();
}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,400,300);

p._tick = _tick;
p._handleDrawEnd = _handleDrawEnd;
p._updateVisibility = _updateVisibility;
p.draw = _componentDraw;



(lib.Tween30 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Bitmap27();
	this.instance.setTransform(826.15,-168,0.9598,0.6718,0,0,180);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-53,-168,879.2,335.9);


(lib.Tween25 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Bitmap21();
	this.instance.setTransform(-10,-10,0.2703,0.2665);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-10,-10,20,20);


(lib.Tween24 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Bitmap21();
	this.instance.setTransform(-10,-10,0.2703,0.2665);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-10,-10,20,20);


(lib.Tween23 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Bitmap23();
	this.instance.setTransform(-10,-10,0.278,0.3078);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-10,-10,20,20);


(lib.Tween22 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Bitmap24();
	this.instance.setTransform(-10,-10,0.2667,0.3573);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-10,-10,20,20);


(lib.Tween21 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Bitmap26();
	this.instance.setTransform(-10,-10,0.25,0.3278);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-10,-10,20,20);


(lib.Tween20 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Bitmap25();
	this.instance.setTransform(-10,-10,0.2469,0.4);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-10,-10,20,20);


(lib.Tween3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.beginFill("#999999").beginStroke().moveTo(-38.9,38.9).curveTo(-55,22.8,-55,0).curveTo(-55,-22.8,-38.9,-38.9).curveTo(-22.8,-55,0,-55).curveTo(22.8,-55,38.9,-38.9).curveTo(55,-22.8,55,0).curveTo(55,22.8,38.9,38.9).curveTo(22.8,55,0,55).curveTo(-22.8,55,-38.9,38.9).closePath();

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-55,-55,110,110);


(lib.Tween2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.beginFill("#FFCC66").beginStroke().moveTo(-38.6,38.6).curveTo(-54.5,22.6,-54.5,-0).curveTo(-54.5,-22.6,-38.6,-38.5).curveTo(-22.6,-54.5,0,-54.5).curveTo(21.5,-54.5,37,-40.1).lineTo(38.5,-38.5).curveTo(54.5,-22.6,54.5,-0).curveTo(54.5,22.6,38.5,38.6).lineTo(37,40).curveTo(21.5,54.5,0,54.5).curveTo(-22.6,54.5,-38.6,38.6).closePath();

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-54.5,-54.5,109,109);


(lib.Tween1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.beginFill("#FFCC66").beginStroke().moveTo(-38.6,38.5).curveTo(-54.5,22.6,-54.5,0).curveTo(-54.5,-22.6,-38.6,-38.6).curveTo(-22.6,-54.5,0,-54.5).curveTo(21.5,-54.5,37,-40).lineTo(38.5,-38.6).curveTo(54.5,-22.6,54.5,0).curveTo(54.5,22.6,38.5,38.5).lineTo(37,40.1).curveTo(21.5,54.5,0,54.5).curveTo(-22.6,54.5,-38.6,38.5).closePath();

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-54.5,-54.5,109,109);


(lib.Symbol16 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.text = new cjs.Text("KZ21", "italic bold 40px 'Times New Roman'", "#FFFFFF");
	this.text.lineHeight = 45;
	this.text.lineWidth = 100;
	this.text.parent = this;
	this.text.setTransform(2,2);
	this.text.shadow = new cjs.Shadow("rgba(204,204,204,1)",0,0,20);

	this.timeline.addTween(cjs.Tween.get(this.text).wait(1).to({color:"#CCCCCC"},0).wait(1).to({color:"#999999"},0).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-21,-21,150,110);


(lib.Symbol15 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.beginFill("#FCFFFF").beginStroke().moveTo(-7.5,0).lineTo(0,-7.5).lineTo(7.5,-0).lineTo(-0,7.5).closePath();
	this.shape.setTransform(7.475,7.525);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.beginFill("#CCCCCC").beginStroke().moveTo(-7.5,0).lineTo(0,-7.5).lineTo(7.5,-0).lineTo(-0,7.5).closePath();
	this.shape_1.setTransform(7.475,7.525);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.beginFill("#999999").beginStroke().moveTo(-7.5,0).lineTo(0,-7.5).lineTo(7.5,-0).lineTo(-0,7.5).closePath();
	this.shape_2.setTransform(7.475,7.525);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,15,15.1);


(lib.Symbol12 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.beginFill().beginStroke("#FFFF99").setStrokeStyle(1,1,1).moveTo(40.6,-23).lineTo(-40.6,23);
	this.shape.setTransform(40.6,23);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Symbol12, new cjs.Rectangle(-1,-1,83.2,48), null);


(lib.Symbol10 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.beginFill().beginStroke("rgba(255,255,153,0.498)").setStrokeStyle(1,1,1).moveTo(18.9,-64.5).lineTo(-18.9,64.5);
	this.shape.setTransform(18.925,64.55);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Symbol10, new cjs.Rectangle(-1,-1,39.9,131.1), null);


(lib.Symbol9 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.beginFill("rgba(255,255,153,0.298)").beginStroke().moveTo(-10.9,7.1).lineTo(-10.9,-7.1).lineTo(2.6,-11.4).lineTo(10.9,0).lineTo(2.6,11.4).closePath();
	this.shape.setTransform(10.875,11.425);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Symbol9, new cjs.Rectangle(0,0,21.8,22.9), null);


(lib.Symbol8 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.beginFill().beginStroke("#FFFF99").setStrokeStyle(1,1,1).moveTo(86.2,0).curveTo(86.2,35.7,60.9,61).curveTo(35.7,86.2,0,86.2).curveTo(-32.7,86.2,-56.7,65).curveTo(-58.9,63,-61,61).curveTo(-86.2,35.7,-86.2,0).curveTo(-86.2,-35.7,-61,-61).curveTo(-35.7,-86.2,0,-86.2).curveTo(35.7,-86.2,60.9,-61).curveTo(86.2,-35.7,86.2,0).closePath();
	this.shape.setTransform(86.2,86.2);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Symbol8, new cjs.Rectangle(-1,-1,174.4,174.4), null);


(lib.Symbol6 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.beginFill("#FFFF99").beginStroke().moveTo(-25.7,25.6).curveTo(-36.3,15,-36.3,-0).curveTo(-36.3,-15,-25.7,-25.7).curveTo(-15,-36.3,-0,-36.3).curveTo(15,-36.3,25.6,-25.7).curveTo(36.3,-15,36.3,-0).curveTo(36.3,15,25.6,25.6).curveTo(15,36.3,-0,36.3).curveTo(-15,36.3,-25.7,25.6).closePath();
	this.shape.setTransform(36.3,36.3);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Symbol6, new cjs.Rectangle(0,0,72.6,72.6), null);


(lib.Symbol2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.beginFill("#77D0FD").beginStroke().moveTo(-286.4,226.2).lineTo(-286.4,-226.2).lineTo(286.4,-226.2).lineTo(286.4,226.2).closePath();
	this.shape.setTransform(286.375,226.2);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,572.8,452.4);


(lib.Scene_1_Sky_Darken = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Sky_Darken
	this.instance = new lib.Bitmap6();
	this.instance.setTransform(0,207,0.9178,1.4433);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(199).to({_off:false},0).wait(85));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();


(lib.Scene_1_Sky = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Sky
	this.instance = new lib.Bitmap5();
	this.instance.setTransform(0,0,0.9628,1.7121);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(99).to({_off:false},0).wait(100));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();


(lib.Scene_1_Grass_Darken = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Grass_Darken
	this.instance = new lib.SkyDarkend();
	this.instance.setTransform(0,0,0.9933,1.5578);

	this.instance_1 = new lib.GrassDarken();
	this.instance_1.setTransform(0,-21,0.9178,1.4476);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_1},{t:this.instance}]},199).wait(85));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();


(lib.Scene_1_Grass = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Grass
	this.instance = new lib.Bitmap17();
	this.instance.setTransform(0,234,0.6305,0.6305);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(99).to({_off:false},0).wait(100));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();


(lib.Scene_1_Chimmy = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Chimmy
	this.instance = new lib.ChimmyStockPhoto();
	this.instance.setTransform(114,234,0.4852,0.4852);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(99).to({_off:false},0).wait(40).to({x:349},0).wait(39).to({x:-118},0).wait(40).to({x:110},0).wait(40).to({x:-125},0).wait(25).to({x:-338},0).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();


(lib.Scene_1_car = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// car
	this.instance = new lib.Bitmap18();
	this.instance.setTransform(624.25,283.9,0.1744,0.1744,20.9633);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(90));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();


(lib.Scene_1_bird2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// bird2
	this.instance = new lib.Bitmap20();
	this.instance.setTransform(-13,108,0.5263,0.6896);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(39).to({_off:false},0).wait(49).to({guide:{path:[-3.1,118.9,-3,118.9,-3,118.9,3.4,121.1,14.7,122.9,15.8,123.1,17.1,123.3,18.1,123.4,19.1,123.6,20.1,123.7,21.1,123.8,30,124.9,41.3,125.8,64.8,127.7,83.6,127.7,94.9,127.7,98.4,127.3,102.4,126.8,106.4,124.8,112.4,121.4,118.2,118.4,129.1,112.6,144.5,106.1,147.6,104.8,162.1,83.4,172.4,68,176.6,61.1,183.9,50.1,193.8,40.4,206.2,28.1,214.3,27.5,225,26.5,239.5,12.7,250.4,2.3,253.3,-5.3,253.6,-5.9,253.8,-6.6]}},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();


(lib.Scene_1_Background = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Background
	this.shape = new cjs.Shape();
	this.shape.graphics.beginFill("#FFFFFF").beginStroke().moveTo(-410,259.5).lineTo(-410,-259.5).lineTo(410,-259.5).lineTo(410,259.5).closePath();
	this.shape.setTransform(390.025,240.525);
	this.shape._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(284).to({_off:false},0).wait(116));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();


(lib.NextButton = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.text = new cjs.Text(">", "40px 'Arial Rounded MT Bold'");
	this.text.textAlign = "center";
	this.text.lineHeight = 48;
	this.text.lineWidth = 106;
	this.text.parent = this;
	this.text.setTransform(55.0715,2,0.9998,0.9998);

	this.timeline.addTween(cjs.Tween.get(this.text).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,110.1,50.3);


(lib.MusicButton = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_2 = function() {
		playSound("ButtonSong");
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(2).call(this.frame_2).wait(1));

	// Layer_1
	this.text = new cjs.Text("Play The Music", "40px 'Gabriola'");
	this.text.textAlign = "center";
	this.text.lineHeight = 76;
	this.text.lineWidth = 188;
	this.text.parent = this;
	this.text.setTransform(96.2,2);

	this.timeline.addTween(cjs.Tween.get(this.text).wait(3));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,192.4,77.7);


(lib.Symbol1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.___Camera___ = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.visible = false;
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(2));

	// cameraBoundary
	this.shape = new cjs.Shape();
	this.shape.graphics.beginFill().beginStroke("rgba(0,0,0,0)").setStrokeStyle(2,1,1,3,true).moveTo(275,200).lineTo(-275,200).lineTo(-275,-200).lineTo(275,-200).closePath();

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(2));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-401,-251,802,502);


(lib.Tween32 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Bitmap33();
	this.instance.setTransform(-141,-11,0.0957,0.0957);

	this.instance_1 = new lib.Bitmap33();
	this.instance_1.setTransform(203,68,0.0957,0.0957);

	this.instance_2 = new lib.Bitmap32();
	this.instance_2.setTransform(91,-11,0.1285,0.1285);

	this.instance_3 = new lib.Bitmap30();
	this.instance_3.setTransform(-251,55,0.112,0.112);

	this.instance_4 = new lib.Symbol1();
	this.instance_4.setTransform(197,-44.75,1,1,0,0,0,44.2,44.2);
	this.instance_4.shadow = new cjs.Shadow("rgba(255,255,204,1)",0,0,10);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-251,-99.9,549.1,201.8);


(lib.Symbol13 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Tween3("synched",0);
	this.instance.setTransform(55,55);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Symbol13, new cjs.Rectangle(0,0.1,110,110), null);


(lib.Symbol7 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Tween3("synched",0);
	this.instance.setTransform(55,55);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Symbol7, new cjs.Rectangle(0,0.1,110,110), null);


(lib.Symbol5 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Tween2("synched",0);
	this.instance.setTransform(54.5,54.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Symbol5, new cjs.Rectangle(0.1,0.1,109,109), null);


(lib.Symbol4 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Tween30("synched",0);
	this.instance.setTransform(1405.5,168,1.1158,1,0,0,180);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Symbol4, new cjs.Rectangle(483.7,0,980.8999999999999,335.9), null);


(lib.Symbol3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Tween1("synched",0);
	this.instance.setTransform(54.5,54.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Symbol3, new cjs.Rectangle(0,0.1,109,109), null);


(lib.Scene_1_Video = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Video
	this.instance = new lib.an_Video({'id': '', 'src':'videos/The%20Tomato%20Song.mp4', 'autoplay':true, 'controls':true, 'muted':false, 'loop':true, 'poster':'', 'preload':true, 'class':'video'});

	this.instance.setTransform(398.55,209.2,1.0649,0.7999,0,0,0,200.1,150.1);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(284).to({_off:false},0).wait(115).to({scaleX:0.9999,scaleY:0.9999,x:388.55,y:230.05},0).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();


(lib.Scene_1_SunMoon = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// SunMoon
	this.instance = new lib.Symbol3();
	this.instance.setTransform(-54.65,194,1,1,0,0,0,54.5,54.5);
	this.instance.shadow = new cjs.Shadow("rgba(255,255,102,1)",0,0,50);
	this.instance._off = true;

	this.instance_1 = new lib.Symbol5();
	this.instance_1.setTransform(856.85,200.4,1,1,0,0,0,54.5,54.5);
	this.instance_1.shadow = new cjs.Shadow("rgba(255,255,102,1)",0,0,50);

	this.instance_2 = new lib.Symbol7();
	this.instance_2.setTransform(-57.2,196.15,1,1,0,0,0,55,55);
	this.instance_2.shadow = new cjs.Shadow("rgba(204,204,204,1)",0,0,50);
	this.instance_2._off = true;
	this.instance_2.cache(-2,-2,114,114);

	this.instance_3 = new lib.Symbol13();
	this.instance_3.setTransform(857.25,204.45,1,1,0,0,0,55,55);
	this.instance_3.shadow = new cjs.Shadow("rgba(204,204,204,1)",0,0,50);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance}]},99).to({state:[{t:this.instance}]},98).to({state:[{t:this.instance_1}]},1).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.instance_2}]},83).to({state:[{t:this.instance_3}]},1).wait(1));
	this.timeline.addTween(cjs.Tween.get(this.instance).wait(99).to({_off:false},0).to({guide:{path:[-54.6,194,-22.8,167.2,21.7,143.2,177.4,59.6,397.4,59.6,617.5,59.6,773.1,143.2,817.6,167.2,849.5,194]}},98).to({_off:true,guide:{path:[849.5,194,853.3,197.2,856.9,200.4]}},1).wait(86));
	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(199).to({_off:false},0).to({guide:{path:[-57.1,196.2,-24.5,168.2,21.8,143.2,177.5,59.6,397.5,59.6,617.5,59.6,773.1,143.2,818.3,167.5,850.4,194.8]}},83).to({_off:true,guide:{path:[850.4,194.7,854.9,198.6,859.1,202.4]}},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();


(lib.Scene_1_sun = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// sun
	this.instance = new lib.Symbol12();
	this.instance.setTransform(597.6,115.1,1,1,0,0,0,40.7,23.1);
	this.instance.shadow = new cjs.Shadow("rgba(255,255,204,1)",0,0,30);
	this.instance.filters = [new cjs.ColorFilter(0.1, 0.1, 0.1, 1, 229.5, 229.5, 229.5, 0)];
	this.instance.cache(-3,-3,87,52);

	this.instance_1 = new lib.Symbol9();
	this.instance_1.setTransform(696.25,91.2,0.3218,0.3501,0,0,0,11.3,11.8);
	this.instance_1.shadow = new cjs.Shadow("rgba(255,255,204,1)",0,0,10);
	this.instance_1.compositeOperation = "lighten";

	this.instance_2 = new lib.Symbol9();
	this.instance_2.setTransform(675.2,110.65,0.5517,0.5689,0,0,0,11.2,11.7);
	this.instance_2.shadow = new cjs.Shadow("rgba(255,255,204,1)",0,0,10);
	this.instance_2.compositeOperation = "lighten";

	this.instance_3 = new lib.Symbol9();
	this.instance_3.setTransform(647.8,135.75,0.6896,0.7002,0,0,0,11,11.6);
	this.instance_3.shadow = new cjs.Shadow("rgba(255,255,204,1)",0,0,10);
	this.instance_3.compositeOperation = "lighten";

	this.instance_4 = new lib.Symbol10();
	this.instance_4.setTransform(723.95,166.65,1,1,0,0,0,19,64.7);
	this.instance_4.shadow = new cjs.Shadow("rgba(255,255,204,1)",0,0,50);
	this.instance_4.filters = [new cjs.ColorFilter(0.1, 0.1, 0.1, 1, 229.5, 229.5, 229.5, 0)];
	this.instance_4.cache(-3,-3,44,135);

	this.instance_5 = new lib.Symbol9();
	this.instance_5.setTransform(611.1,165.75,1,1,0,0,0,11,11.5);
	this.instance_5.shadow = new cjs.Shadow("rgba(255,255,204,1)",0,0,10);
	this.instance_5.compositeOperation = "lighten";

	this.instance_6 = new lib.Symbol8();
	this.instance_6.setTransform(675.05,138,1,1,0,0,0,86.3,86.3);
	this.instance_6.shadow = new cjs.Shadow("rgba(255,255,153,1)",0,0,10);
	this.instance_6.filters = [new cjs.ColorFilter(0.1, 0.1, 0.1, 1, 229.5, 229.5, 229.5, 0)];
	this.instance_6.cache(-3,-3,178,178);

	this.instance_7 = new lib.Symbol6();
	this.instance_7.setTransform(731.15,58.85,0.9917,1,0,0,0,36.4,36.4);
	this.instance_7.shadow = new cjs.Shadow("rgba(255,255,204,1)",0,0,50);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_7},{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(90));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();


(lib.Scene_1_SongButton = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// SongButton
	this.SongButton = new lib.MusicButton();
	this.SongButton.name = "SongButton";
	this.SongButton.setTransform(580.4,56.15,1,1,0,0,0,96.2,38.8);
	new cjs.ButtonHelper(this.SongButton, 0, 1, 2);

	this.timeline.addTween(cjs.Tween.get(this.SongButton).wait(284));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();


(lib.Scene_1_sky2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// sky2
	this.instance = new lib.Symbol2("synched",0);
	this.instance.setTransform(400,249.9,1.3967,1.1052,0,0,0,286.4,226.1);

	this.shape = new cjs.Shape();
	this.shape.graphics.beginFill().beginStroke("#323232").setStrokeStyle(1,1,1).moveTo(286.4,-188.5).lineTo(286.4,188.5).moveTo(-286.4,188.5).lineTo(-286.4,-188.5);
	this.shape.setTransform(581.225,274.05);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape},{t:this.instance}]}).wait(90));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();


(lib.Scene_1_road = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// road
	this.instance = new lib.Symbol4("synched",0);
	this.instance.setTransform(-323.2,275.65,1.151,1.3525,0,0,0,488.8,170.1);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({regY:170.2,scaleY:1.3524,x:7.95,y:275.75},89).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();


(lib.Scene_1_nav = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// nav
	this.link = new lib.Symbol16();
	this.link.name = "link";
	this.link.setTransform(188.75,59.9,1,1,0,0,0,52.1,32.1);
	new cjs.ButtonHelper(this.link, 0, 1, 2);

	this.instance = new lib.Symbol15();
	this.instance.setTransform(52.85,174.15,0.9999,0.9999,0,0,0,7.6,7.7);
	this.instance.shadow = new cjs.Shadow("rgba(204,204,204,1)",0,0,10);
	new cjs.ButtonHelper(this.instance, 0, 1, 2);

	this.instance_1 = new lib.Symbol15();
	this.instance_1.setTransform(52.75,118.85,1,1,0,0,0,7.5,7.5);
	this.instance_1.shadow = new cjs.Shadow("rgba(204,204,204,1)",0,0,10);
	new cjs.ButtonHelper(this.instance_1, 0, 1, 2);

	this.shape = new cjs.Shape();
	this.shape.graphics.beginFill().beginStroke("#FFFFFF").setStrokeStyle(1,1,1).moveTo(0,-13.9).lineTo(0,14);
	this.shape.setTransform(52.4,146.65);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape},{t:this.instance_1},{t:this.instance},{t:this.link}]}).wait(284));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();


(lib.Scene_1_Cloud = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Cloud
	this.instance = new lib.Tween32("synched",0);
	this.instance.setTransform(302.55,96.15,1,1,0,0,0,0.1,0.1);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({x:357.2,y:96.05},89).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();


(lib.Scene_1_Button = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Button
	this.instance = new lib.NextButton();
	this.instance.setTransform(121.1,334,0.9999,0.9999,0,0,0,55.1,25.2);
	new cjs.ButtonHelper(this.instance, 0, 1, 1);

	this.button_1 = new lib.NextButton();
	this.button_1.name = "button_1";
	this.button_1.setTransform(115.35,334.05,1,1,0,0,0,55.1,25.2);
	new cjs.ButtonHelper(this.button_1, 0, 1, 1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.button_1}]},89).to({state:[{t:this.button_1}]},194).to({state:[{t:this.button_1}]},116).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();


(lib.Scene_1_bird1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// bird1
	this.instance = new lib.Tween25("synched",0);
	this.instance.setTransform(-0.1,154.65);

	this.instance_1 = new lib.Tween24("synched",0);
	this.instance_1.setTransform(148,147);
	this.instance_1._off = true;

	this.instance_2 = new lib.Tween23("synched",0);
	this.instance_2.setTransform(272,151);
	this.instance_2._off = true;

	this.instance_3 = new lib.Tween22("synched",0);
	this.instance_3.setTransform(395.45,158);
	this.instance_3._off = true;

	this.instance_4 = new lib.Tween20("synched",0);
	this.instance_4.setTransform(519.5,155);
	this.instance_4._off = true;

	this.instance_5 = new lib.Tween21("synched",0);
	this.instance_5.setTransform(641,152);
	this.instance_5._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).to({_off:true,x:148,y:147},14).wait(76));
	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({_off:false},14).to({_off:true,x:272,y:151},15).wait(61));
	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(14).to({_off:false},15).to({_off:true,x:395.45,y:158},15).wait(46));
	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(29).to({_off:false},15).to({_off:true,x:519.5,y:155},15).wait(31));
	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(44).to({_off:false},15).to({_off:true,x:641,y:152},15).wait(16));
	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(59).to({_off:false},15).to({x:805,y:155.5},15).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();


// stage content:
(lib.join = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = false; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.actionFrames = [0,34,89,283,399];
	this.___GetDepth___ = function(obj) {
		var depth = obj.depth;
		var cameraObj = this.___camera___instance;
		if(cameraObj && cameraObj.depth && obj.isAttachedToCamera)
		{
			depth += depth + cameraObj.depth;
		}
		return depth;
		}
	this.___needSorting___ = function() {
		for (var i = 0; i < this.numChildren - 1; i++)
		{
			var prevDepth = this.___GetDepth___(this.getChildAt(i));
			var nextDepth = this.___GetDepth___(this.getChildAt(i + 1));
			if (prevDepth < nextDepth)
				return true;
		}
		return false;
	}
	this.___sortFunction___ = function(obj1, obj2) {
		return (this.exportRoot.___GetDepth___(obj2) - this.exportRoot.___GetDepth___(obj1));
	}
	this.on('tick', function (event){
		var curTimeline = event.currentTarget;
		if (curTimeline.___needSorting___()){
			this.sortChildren(curTimeline.___sortFunction___);
		}
	});

	// timeline functions:
	this.frame_0 = function() {
		if(this.SongButton.parent == undefined || this.SongButton.parent == this)
		this.SongButton = this.SongButton.SongButton;
		this.link = this.nav.link;
	}
	this.frame_34 = function() {
		/* Click to Go to Web Page
		Clicking on the specified symbol instance loads the URL in a new browser window.
		
		Instructions:
		1. Replace http://www.adobe.com with the desired URL address.
		   Keep the quotation marks ("").
		*/
		
		this.link.addEventListener("click", fl_ClickToGoToWebPage);
		
		function fl_ClickToGoToWebPage() {
			window.open("http://www.bt21.com", "_blank");
		}
	}
	this.frame_89 = function() {
		this.button_1 = this.Button.button_1;
		this.button_1.addEventListener("click", fl_ClickToGoToAndPlayFromFrame_3.bind(this));
		
		function fl_ClickToGoToAndPlayFromFrame_3()
		{
			this.gotoAndPlay(100);
		}
		this.stop();
		this.stop();
	}
	this.frame_283 = function() {
		this.button_1 = undefined;this.button_1 = this.Button.button_1;
		this.button_1.addEventListener("click", fl_ClickToGoToAndPlayFromFrame_5.bind(this));
		
		function fl_ClickToGoToAndPlayFromFrame_5()
		{
			this.gotoAndPlay(285);
		}
		this.stop();
		this.stop();
	}
	this.frame_399 = function() {
		this.button_1 = undefined;this.button_1 = this.Button.button_1;
		this.___loopingOver___ = true;
		this.button_1.addEventListener("click", fl_ClickToGoToAndPlayFromFrame_7.bind(this));
		
		function fl_ClickToGoToAndPlayFromFrame_7()
		{
			this.gotoAndPlay(1);
		}
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(34).call(this.frame_34).wait(55).call(this.frame_89).wait(194).call(this.frame_283).wait(116).call(this.frame_399).wait(1));

	// Camera
	this.___camera___instance = new lib.___Camera___();
	this.___camera___instance.name = "___camera___instance";
	this.___camera___instance.setTransform(530.9,165.15,0.6543,0.6543,0,0,0,0.1,0.1);
	this.___camera___instance.depth = 0;
	this.___camera___instance.visible = false;

	this.timeline.addTween(cjs.Tween.get(this.___camera___instance).to({regX:0.2,regY:0.3,scaleX:0.998,scaleY:0.998,x:401.55,y:247.9},34).to({_off:true},56).wait(310));

	// Button_obj_
	this.Button = new lib.Scene_1_Button();
	this.Button.name = "Button";
	this.Button.setTransform(121.1,334.05,1.5284,1.5284,0,0,0,348.3,220);
	this.Button.depth = 0;
	this.Button.isAttachedToCamera = 0
	this.Button.isAttachedToMask = 0
	this.Button.layerDepth = 0
	this.Button.layerIndex = 0
	this.Button.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.Button).wait(89).to({regX:123,regY:331.4,scaleX:1.002,scaleY:1.002,y:333.9},0).wait(194).to({regX:121,regY:333.9,scaleX:1,scaleY:1,x:121},0).wait(117));

	// Video_obj_
	this.Video = new lib.Scene_1_Video();
	this.Video.name = "Video";
	this.Video.setTransform(0.05,-0.05,1.5284,1.5284,0,0,0,269.1,1.4);
	this.Video.depth = 0;
	this.Video.isAttachedToCamera = 0
	this.Video.isAttachedToMask = 0
	this.Video.layerDepth = 0
	this.Video.layerIndex = 1
	this.Video.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.Video).wait(271).to({regX:0,regY:0,scaleX:1,scaleY:1,x:0,y:0},0).wait(129));

	// Background_obj_
	this.Background = new lib.Scene_1_Background();
	this.Background.name = "Background";
	this.Background.setTransform(0.05,-0.05,1.5284,1.5284,0,0,0,269.1,1.4);
	this.Background.depth = 0;
	this.Background.isAttachedToCamera = 0
	this.Background.isAttachedToMask = 0
	this.Background.layerDepth = 0
	this.Background.layerIndex = 2
	this.Background.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.Background).wait(284).to({regX:0,regY:0,scaleX:1,scaleY:1,x:0,y:0},0).wait(116));

	// SongButton_obj_
	this.SongButton = new lib.Scene_1_SongButton();
	this.SongButton.name = "SongButton";
	this.SongButton.setTransform(580.35,56.2,1.5284,1.5284,0,0,0,648.8,38.2);
	this.SongButton.depth = 0;
	this.SongButton.isAttachedToCamera = 0
	this.SongButton.isAttachedToMask = 0
	this.SongButton.layerDepth = 0
	this.SongButton.layerIndex = 3
	this.SongButton.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.SongButton).to({_off:true},284).wait(116));

	// nav_obj_
	this.nav = new lib.Scene_1_nav();
	this.nav.name = "nav";
	this.nav.setTransform(142.95,104.65,1.5284,1.5284,0,0,0,362.6,69.9);
	this.nav.depth = 0;
	this.nav.isAttachedToCamera = 0
	this.nav.isAttachedToMask = 0
	this.nav.layerDepth = 0
	this.nav.layerIndex = 4
	this.nav.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.nav).to({_off:true},284).wait(116));

	// sun_obj_
	this.sun = new lib.Scene_1_sun();
	this.sun.name = "sun";
	this.sun.setTransform(661.65,126.95,1.5284,1.5284,0,0,0,702,84.5);
	this.sun.depth = 0;
	this.sun.isAttachedToCamera = 0
	this.sun.isAttachedToMask = 0
	this.sun.layerDepth = 0
	this.sun.layerIndex = 5
	this.sun.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.sun).to({_off:true},90).wait(310));

	// Cloud_obj_
	this.Cloud = new lib.Scene_1_Cloud();
	this.Cloud.name = "Cloud";
	this.Cloud.setTransform(326.05,102.5,1.5284,1.5284,0,0,0,482.4,68.5);
	this.Cloud.depth = 0;
	this.Cloud.isAttachedToCamera = 0
	this.Cloud.isAttachedToMask = 0
	this.Cloud.layerDepth = 0
	this.Cloud.layerIndex = 6
	this.Cloud.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.Cloud).to({regX:327.5,regY:100.5,scaleX:1.002,scaleY:1.002,x:326,y:102.55},89).to({_off:true},1).wait(310));

	// bird2_obj_
	this.bird2 = new lib.Scene_1_bird2();
	this.bird2.name = "bird2";
	this.bird2.setTransform(0.05,-0.05,1.5284,1.5284,0,0,0,269.1,1.4);
	this.bird2.depth = 0;
	this.bird2.isAttachedToCamera = 0
	this.bird2.isAttachedToMask = 0
	this.bird2.layerDepth = 0
	this.bird2.layerIndex = 7
	this.bird2.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.bird2).wait(39).to({regX:-1,regY:116.8,scaleX:1.002,scaleY:1.002,x:-3.15,y:118.9},0).wait(49).to({regX:2.1,regY:-1.9,x:-0.05,y:-0.05},1).to({_off:true},1).wait(310));

	// bird1mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_0 = new cjs.Graphics().moveTo(-205.7,140.4).lineTo(-205.7,47.1).lineTo(-100.2,47.1).lineTo(-100.2,140.4).closePath();
	var mask_graphics_1 = new cjs.Graphics().moveTo(-199.4,140.4).lineTo(-199.4,47.2).lineTo(-93.9,47.2).lineTo(-93.9,140.4).closePath();
	var mask_graphics_2 = new cjs.Graphics().moveTo(-193.1,140.4).lineTo(-193.1,47.2).lineTo(-87.6,47.2).lineTo(-87.6,140.4).closePath();
	var mask_graphics_3 = new cjs.Graphics().moveTo(-186.8,140.4).lineTo(-186.8,47.2).lineTo(-81.4,47.2).lineTo(-81.4,140.4).closePath();
	var mask_graphics_4 = new cjs.Graphics().moveTo(-180.5,140.4).lineTo(-180.5,47.2).lineTo(-75.1,47.2).lineTo(-75.1,140.4).closePath();
	var mask_graphics_5 = new cjs.Graphics().moveTo(-174.2,140.4).lineTo(-174.2,47.2).lineTo(-68.8,47.2).lineTo(-68.8,140.4).closePath();
	var mask_graphics_6 = new cjs.Graphics().moveTo(-168,140.4).lineTo(-168,47.2).lineTo(-62.5,47.2).lineTo(-62.5,140.4).closePath();
	var mask_graphics_7 = new cjs.Graphics().moveTo(-161.7,140.4).lineTo(-161.7,47.2).lineTo(-56.3,47.2).lineTo(-56.3,140.4).closePath();
	var mask_graphics_8 = new cjs.Graphics().moveTo(-155.4,140.5).lineTo(-155.4,47.2).lineTo(-50,47.2).lineTo(-50,140.5).closePath();
	var mask_graphics_9 = new cjs.Graphics().moveTo(-149.1,140.5).lineTo(-149.1,47.2).lineTo(-43.7,47.2).lineTo(-43.7,140.5).closePath();
	var mask_graphics_10 = new cjs.Graphics().moveTo(-142.9,140.5).lineTo(-142.9,47.2).lineTo(-37.4,47.2).lineTo(-37.4,140.5).closePath();
	var mask_graphics_11 = new cjs.Graphics().moveTo(-136.6,140.5).lineTo(-136.6,47.2).lineTo(-31.2,47.2).lineTo(-31.2,140.5).closePath();
	var mask_graphics_12 = new cjs.Graphics().moveTo(-130.3,140.5).lineTo(-130.3,47.2).lineTo(-24.9,47.2).lineTo(-24.9,140.5).closePath();
	var mask_graphics_13 = new cjs.Graphics().moveTo(-124,140.5).lineTo(-124,47.2).lineTo(-18.6,47.2).lineTo(-18.6,140.5).closePath();
	var mask_graphics_14 = new cjs.Graphics().moveTo(-117.8,140.5).lineTo(-117.8,47.3).lineTo(-12.3,47.3).lineTo(-12.3,140.5).closePath();
	var mask_graphics_15 = new cjs.Graphics().moveTo(-111.5,140.5).lineTo(-111.5,47.3).lineTo(-6.1,47.3).lineTo(-6.1,140.5).closePath();
	var mask_graphics_16 = new cjs.Graphics().moveTo(-105.2,140.5).lineTo(-105.2,47.3).lineTo(0.3,47.3).lineTo(0.3,140.5).closePath();
	var mask_graphics_17 = new cjs.Graphics().moveTo(-98.9,140.5).lineTo(-98.9,47.3).lineTo(6.5,47.3).lineTo(6.5,140.5).closePath();
	var mask_graphics_18 = new cjs.Graphics().moveTo(-92.7,140.5).lineTo(-92.7,47.3).lineTo(12.8,47.3).lineTo(12.8,140.5).closePath();
	var mask_graphics_19 = new cjs.Graphics().moveTo(-86.4,140.5).lineTo(-86.4,47.3).lineTo(19.1,47.3).lineTo(19.1,140.5).closePath();
	var mask_graphics_20 = new cjs.Graphics().moveTo(-80.1,140.5).lineTo(-80.1,47.3).lineTo(25.4,47.3).lineTo(25.4,140.5).closePath();
	var mask_graphics_21 = new cjs.Graphics().moveTo(-73.8,140.5).lineTo(-73.8,47.3).lineTo(31.6,47.3).lineTo(31.6,140.5).closePath();
	var mask_graphics_22 = new cjs.Graphics().moveTo(-67.6,140.5).lineTo(-67.6,47.3).lineTo(37.9,47.3).lineTo(37.9,140.5).closePath();
	var mask_graphics_23 = new cjs.Graphics().moveTo(-61.3,140.5).lineTo(-61.3,47.3).lineTo(44.2,47.3).lineTo(44.2,140.5).closePath();
	var mask_graphics_24 = new cjs.Graphics().moveTo(-55,140.6).lineTo(-55,47.4).lineTo(50.5,47.4).lineTo(50.5,140.6).closePath();
	var mask_graphics_25 = new cjs.Graphics().moveTo(-52.7,140.6).lineTo(-52.7,47.4).lineTo(52.7,47.4).lineTo(52.7,140.6).closePath();
	var mask_graphics_26 = new cjs.Graphics().moveTo(-52.7,140.6).lineTo(-52.7,47.4).lineTo(52.7,47.4).lineTo(52.7,140.6).closePath();
	var mask_graphics_27 = new cjs.Graphics().moveTo(-52.7,140.6).lineTo(-52.7,47.4).lineTo(52.7,47.4).lineTo(52.7,140.6).closePath();
	var mask_graphics_28 = new cjs.Graphics().moveTo(-52.7,140.6).lineTo(-52.7,47.4).lineTo(52.7,47.4).lineTo(52.7,140.6).closePath();
	var mask_graphics_29 = new cjs.Graphics().moveTo(-52.7,140.6).lineTo(-52.7,47.4).lineTo(52.7,47.4).lineTo(52.7,140.6).closePath();
	var mask_graphics_30 = new cjs.Graphics().moveTo(-52.7,140.6).lineTo(-52.7,47.4).lineTo(52.7,47.4).lineTo(52.7,140.6).closePath();
	var mask_graphics_31 = new cjs.Graphics().moveTo(-52.7,140.6).lineTo(-52.7,47.4).lineTo(52.7,47.4).lineTo(52.7,140.6).closePath();
	var mask_graphics_32 = new cjs.Graphics().moveTo(-52.7,140.6).lineTo(-52.7,47.4).lineTo(52.7,47.4).lineTo(52.7,140.6).closePath();
	var mask_graphics_33 = new cjs.Graphics().moveTo(-51.2,140.6).lineTo(-51.2,47.4).lineTo(54.2,47.4).lineTo(54.2,140.6).closePath();
	var mask_graphics_34 = new cjs.Graphics().moveTo(104.2,93.9).lineTo(104.2,32.7).lineTo(173.4,32.7).lineTo(173.4,93.9).closePath();
	var mask_graphics_35 = new cjs.Graphics().moveTo(108.3,93.9).lineTo(108.3,32.8).lineTo(177.5,32.8).lineTo(177.5,93.9).closePath();
	var mask_graphics_36 = new cjs.Graphics().moveTo(112.5,93.9).lineTo(112.5,32.8).lineTo(181.6,32.8).lineTo(181.6,93.9).closePath();
	var mask_graphics_37 = new cjs.Graphics().moveTo(116.6,93.9).lineTo(116.6,32.8).lineTo(185.7,32.8).lineTo(185.7,93.9).closePath();
	var mask_graphics_38 = new cjs.Graphics().moveTo(120.7,93.9).lineTo(120.7,32.8).lineTo(189.8,32.8).lineTo(189.8,93.9).closePath();
	var mask_graphics_39 = new cjs.Graphics().moveTo(124.8,93.9).lineTo(124.8,32.8).lineTo(194,32.8).lineTo(194,93.9).closePath();
	var mask_graphics_40 = new cjs.Graphics().moveTo(128.9,93.9).lineTo(128.9,32.8).lineTo(198.1,32.8).lineTo(198.1,93.9).closePath();
	var mask_graphics_41 = new cjs.Graphics().moveTo(133,93.9).lineTo(133,32.8).lineTo(202.2,32.8).lineTo(202.2,93.9).closePath();
	var mask_graphics_42 = new cjs.Graphics().moveTo(137.2,93.9).lineTo(137.2,32.8).lineTo(206.3,32.8).lineTo(206.3,93.9).closePath();
	var mask_graphics_43 = new cjs.Graphics().moveTo(141.3,93.9).lineTo(141.3,32.8).lineTo(210.4,32.8).lineTo(210.4,93.9).closePath();
	var mask_graphics_44 = new cjs.Graphics().moveTo(145.4,93.9).lineTo(145.4,32.8).lineTo(214.5,32.8).lineTo(214.5,93.9).closePath();
	var mask_graphics_45 = new cjs.Graphics().moveTo(149.5,93.9).lineTo(149.5,32.8).lineTo(218.7,32.8).lineTo(218.7,93.9).closePath();
	var mask_graphics_46 = new cjs.Graphics().moveTo(153.6,93.9).lineTo(153.6,32.8).lineTo(222.8,32.8).lineTo(222.8,93.9).closePath();
	var mask_graphics_47 = new cjs.Graphics().moveTo(157.7,93.9).lineTo(157.7,32.8).lineTo(226.9,32.8).lineTo(226.9,93.9).closePath();
	var mask_graphics_48 = new cjs.Graphics().moveTo(161.9,93.9).lineTo(161.9,32.8).lineTo(231,32.8).lineTo(231,93.9).closePath();
	var mask_graphics_49 = new cjs.Graphics().moveTo(166,93.9).lineTo(166,32.8).lineTo(235.1,32.8).lineTo(235.1,93.9).closePath();
	var mask_graphics_50 = new cjs.Graphics().moveTo(170.1,94).lineTo(170.1,32.8).lineTo(239.2,32.8).lineTo(239.2,94).closePath();
	var mask_graphics_51 = new cjs.Graphics().moveTo(174.2,94).lineTo(174.2,32.8).lineTo(243.4,32.8).lineTo(243.4,94).closePath();
	var mask_graphics_52 = new cjs.Graphics().moveTo(178.3,94).lineTo(178.3,32.8).lineTo(247.5,32.8).lineTo(247.5,94).closePath();
	var mask_graphics_53 = new cjs.Graphics().moveTo(182.4,94).lineTo(182.4,32.8).lineTo(251.6,32.8).lineTo(251.6,94).closePath();
	var mask_graphics_54 = new cjs.Graphics().moveTo(186.6,94).lineTo(186.6,32.8).lineTo(255.7,32.8).lineTo(255.7,94).closePath();
	var mask_graphics_55 = new cjs.Graphics().moveTo(190.7,94).lineTo(190.7,32.8).lineTo(259.8,32.8).lineTo(259.8,94).closePath();
	var mask_graphics_56 = new cjs.Graphics().moveTo(194.8,94).lineTo(194.8,32.9).lineTo(263.9,32.9).lineTo(263.9,94).closePath();
	var mask_graphics_57 = new cjs.Graphics().moveTo(198.9,94).lineTo(198.9,32.9).lineTo(268.1,32.9).lineTo(268.1,94).closePath();
	var mask_graphics_58 = new cjs.Graphics().moveTo(203,94).lineTo(203,32.9).lineTo(272.2,32.9).lineTo(272.2,94).closePath();
	var mask_graphics_59 = new cjs.Graphics().moveTo(207.1,94).lineTo(207.1,32.9).lineTo(276.3,32.9).lineTo(276.3,94).closePath();
	var mask_graphics_60 = new cjs.Graphics().moveTo(211.3,94).lineTo(211.3,32.9).lineTo(280.4,32.9).lineTo(280.4,94).closePath();
	var mask_graphics_61 = new cjs.Graphics().moveTo(215.4,94).lineTo(215.4,32.9).lineTo(284.5,32.9).lineTo(284.5,94).closePath();
	var mask_graphics_62 = new cjs.Graphics().moveTo(219.5,94).lineTo(219.5,32.9).lineTo(288.6,32.9).lineTo(288.6,94).closePath();
	var mask_graphics_63 = new cjs.Graphics().moveTo(223.6,94).lineTo(223.6,32.9).lineTo(292.7,32.9).lineTo(292.7,94).closePath();
	var mask_graphics_64 = new cjs.Graphics().moveTo(227.7,94).lineTo(227.7,32.9).lineTo(296.9,32.9).lineTo(296.9,94).closePath();
	var mask_graphics_65 = new cjs.Graphics().moveTo(231.8,94).lineTo(231.8,32.9).lineTo(301,32.9).lineTo(301,94).closePath();
	var mask_graphics_66 = new cjs.Graphics().moveTo(235.9,94).lineTo(235.9,32.9).lineTo(305.1,32.9).lineTo(305.1,94).closePath();
	var mask_graphics_67 = new cjs.Graphics().moveTo(240.1,94).lineTo(240.1,32.9).lineTo(309.2,32.9).lineTo(309.2,94).closePath();
	var mask_graphics_68 = new cjs.Graphics().moveTo(244.2,94).lineTo(244.2,32.9).lineTo(313.3,32.9).lineTo(313.3,94).closePath();
	var mask_graphics_69 = new cjs.Graphics().moveTo(248.3,94).lineTo(248.3,32.9).lineTo(317.4,32.9).lineTo(317.4,94).closePath();
	var mask_graphics_70 = new cjs.Graphics().moveTo(252.4,94).lineTo(252.4,32.9).lineTo(321.5,32.9).lineTo(321.5,94).closePath();
	var mask_graphics_71 = new cjs.Graphics().moveTo(256.5,94.1).lineTo(256.5,32.9).lineTo(325.7,32.9).lineTo(325.7,94.1).closePath();
	var mask_graphics_72 = new cjs.Graphics().moveTo(260.6,94.1).lineTo(260.6,32.9).lineTo(329.8,32.9).lineTo(329.8,94.1).closePath();
	var mask_graphics_73 = new cjs.Graphics().moveTo(264.7,94.1).lineTo(264.7,32.9).lineTo(333.9,32.9).lineTo(333.9,94.1).closePath();
	var mask_graphics_74 = new cjs.Graphics().moveTo(268.9,94.1).lineTo(268.9,32.9).lineTo(338,32.9).lineTo(338,94.1).closePath();
	var mask_graphics_75 = new cjs.Graphics().moveTo(273,94.1).lineTo(273,32.9).lineTo(342.1,32.9).lineTo(342.1,94.1).closePath();
	var mask_graphics_76 = new cjs.Graphics().moveTo(277.1,94.1).lineTo(277.1,33).lineTo(346.2,33).lineTo(346.2,94.1).closePath();
	var mask_graphics_77 = new cjs.Graphics().moveTo(281.2,94.1).lineTo(281.2,33).lineTo(350.4,33).lineTo(350.4,94.1).closePath();
	var mask_graphics_78 = new cjs.Graphics().moveTo(285.3,94.1).lineTo(285.3,33).lineTo(354.5,33).lineTo(354.5,94.1).closePath();
	var mask_graphics_79 = new cjs.Graphics().moveTo(289.4,94.1).lineTo(289.4,33).lineTo(358.6,33).lineTo(358.6,94.1).closePath();
	var mask_graphics_80 = new cjs.Graphics().moveTo(293.5,94.1).lineTo(293.5,33).lineTo(362.7,33).lineTo(362.7,94.1).closePath();
	var mask_graphics_81 = new cjs.Graphics().moveTo(297.7,94.1).lineTo(297.7,33).lineTo(366.8,33).lineTo(366.8,94.1).closePath();
	var mask_graphics_82 = new cjs.Graphics().moveTo(301.8,94.1).lineTo(301.8,33).lineTo(370.9,33).lineTo(370.9,94.1).closePath();
	var mask_graphics_83 = new cjs.Graphics().moveTo(305.9,94.1).lineTo(305.9,33).lineTo(375,33).lineTo(375,94.1).closePath();
	var mask_graphics_84 = new cjs.Graphics().moveTo(310,94.1).lineTo(310,33).lineTo(379.2,33).lineTo(379.2,94.1).closePath();
	var mask_graphics_85 = new cjs.Graphics().moveTo(314.1,94.1).lineTo(314.1,33).lineTo(383.3,33).lineTo(383.3,94.1).closePath();
	var mask_graphics_86 = new cjs.Graphics().moveTo(318.2,94.1).lineTo(318.2,33).lineTo(387.4,33).lineTo(387.4,94.1).closePath();
	var mask_graphics_87 = new cjs.Graphics().moveTo(322.4,94.1).lineTo(322.4,33).lineTo(391.5,33).lineTo(391.5,94.1).closePath();
	var mask_graphics_88 = new cjs.Graphics().moveTo(326.5,94.1).lineTo(326.5,33).lineTo(395.6,33).lineTo(395.6,94.1).closePath();
	var mask_graphics_89 = new cjs.Graphics().moveTo(330.6,94.1).lineTo(330.6,33).lineTo(399.7,33).lineTo(399.7,94.1).closePath();

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:mask_graphics_0,x:-205.688,y:140.3564}).wait(1).to({graphics:mask_graphics_1,x:-199.388,y:140.3814}).wait(1).to({graphics:mask_graphics_2,x:-193.088,y:140.3814}).wait(1).to({graphics:mask_graphics_3,x:-186.813,y:140.4314}).wait(1).to({graphics:mask_graphics_4,x:-180.538,y:140.4314}).wait(1).to({graphics:mask_graphics_5,x:-174.238,y:140.4314}).wait(1).to({graphics:mask_graphics_6,x:-167.988,y:140.4314}).wait(1).to({graphics:mask_graphics_7,x:-161.713,y:140.4314}).wait(1).to({graphics:mask_graphics_8,x:-155.438,y:140.4564}).wait(1).to({graphics:mask_graphics_9,x:-149.138,y:140.4564}).wait(1).to({graphics:mask_graphics_10,x:-142.863,y:140.4564}).wait(1).to({graphics:mask_graphics_11,x:-136.613,y:140.4564}).wait(1).to({graphics:mask_graphics_12,x:-130.338,y:140.4564}).wait(1).to({graphics:mask_graphics_13,x:-124.038,y:140.4564}).wait(1).to({graphics:mask_graphics_14,x:-117.763,y:140.5064}).wait(1).to({graphics:mask_graphics_15,x:-111.513,y:140.5064}).wait(1).to({graphics:mask_graphics_16,x:-105.188,y:140.5064}).wait(1).to({graphics:mask_graphics_17,x:-98.938,y:140.5064}).wait(1).to({graphics:mask_graphics_18,x:-92.663,y:140.5064}).wait(1).to({graphics:mask_graphics_19,x:-86.363,y:140.5314}).wait(1).to({graphics:mask_graphics_20,x:-80.088,y:140.5314}).wait(1).to({graphics:mask_graphics_21,x:-73.838,y:140.5314}).wait(1).to({graphics:mask_graphics_22,x:-67.563,y:140.5314}).wait(1).to({graphics:mask_graphics_23,x:-61.263,y:140.5314}).wait(1).to({graphics:mask_graphics_24,x:-54.988,y:140.5814}).wait(1).to({graphics:mask_graphics_25,x:-44.75,y:140.5814}).wait(1).to({graphics:mask_graphics_26,x:-32.2,y:140.5814}).wait(1).to({graphics:mask_graphics_27,x:-19.6,y:140.5814}).wait(1).to({graphics:mask_graphics_28,x:-7.05,y:140.5814}).wait(1).to({graphics:mask_graphics_29,x:5.45,y:140.6064}).wait(1).to({graphics:mask_graphics_30,x:18.05,y:140.6064}).wait(1).to({graphics:mask_graphics_31,x:30.55,y:140.6064}).wait(1).to({graphics:mask_graphics_32,x:43.1,y:140.6064}).wait(1).to({graphics:mask_graphics_33,x:54.213,y:140.6064}).wait(1).to({graphics:mask_graphics_34,x:173.384,y:93.855}).wait(1).to({graphics:mask_graphics_35,x:177.484,y:93.88}).wait(1).to({graphics:mask_graphics_36,x:181.634,y:93.88}).wait(1).to({graphics:mask_graphics_37,x:185.734,y:93.88}).wait(1).to({graphics:mask_graphics_38,x:189.834,y:93.88}).wait(1).to({graphics:mask_graphics_39,x:193.959,y:93.88}).wait(1).to({graphics:mask_graphics_40,x:198.084,y:93.905}).wait(1).to({graphics:mask_graphics_41,x:202.184,y:93.905}).wait(1).to({graphics:mask_graphics_42,x:206.309,y:93.905}).wait(1).to({graphics:mask_graphics_43,x:210.409,y:93.905}).wait(1).to({graphics:mask_graphics_44,x:214.534,y:93.905}).wait(1).to({graphics:mask_graphics_45,x:218.659,y:93.93}).wait(1).to({graphics:mask_graphics_46,x:222.784,y:93.93}).wait(1).to({graphics:mask_graphics_47,x:226.884,y:93.93}).wait(1).to({graphics:mask_graphics_48,x:231.009,y:93.93}).wait(1).to({graphics:mask_graphics_49,x:235.109,y:93.93}).wait(1).to({graphics:mask_graphics_50,x:239.234,y:93.955}).wait(1).to({graphics:mask_graphics_51,x:243.359,y:93.955}).wait(1).to({graphics:mask_graphics_52,x:247.459,y:93.955}).wait(1).to({graphics:mask_graphics_53,x:251.559,y:93.955}).wait(1).to({graphics:mask_graphics_54,x:255.709,y:93.955}).wait(1).to({graphics:mask_graphics_55,x:259.809,y:93.955}).wait(1).to({graphics:mask_graphics_56,x:263.909,y:93.98}).wait(1).to({graphics:mask_graphics_57,x:268.059,y:93.98}).wait(1).to({graphics:mask_graphics_58,x:272.159,y:93.98}).wait(1).to({graphics:mask_graphics_59,x:276.259,y:93.98}).wait(1).to({graphics:mask_graphics_60,x:280.409,y:93.98}).wait(1).to({graphics:mask_graphics_61,x:284.509,y:94.005}).wait(1).to({graphics:mask_graphics_62,x:288.609,y:94.005}).wait(1).to({graphics:mask_graphics_63,x:292.734,y:94.005}).wait(1).to({graphics:mask_graphics_64,x:296.859,y:94.005}).wait(1).to({graphics:mask_graphics_65,x:300.959,y:94.005}).wait(1).to({graphics:mask_graphics_66,x:305.084,y:94.03}).wait(1).to({graphics:mask_graphics_67,x:309.209,y:94.03}).wait(1).to({graphics:mask_graphics_68,x:313.309,y:94.03}).wait(1).to({graphics:mask_graphics_69,x:317.434,y:94.03}).wait(1).to({graphics:mask_graphics_70,x:321.534,y:94.03}).wait(1).to({graphics:mask_graphics_71,x:325.659,y:94.055}).wait(1).to({graphics:mask_graphics_72,x:329.784,y:94.055}).wait(1).to({graphics:mask_graphics_73,x:333.884,y:94.055}).wait(1).to({graphics:mask_graphics_74,x:338.009,y:94.055}).wait(1).to({graphics:mask_graphics_75,x:342.134,y:94.055}).wait(1).to({graphics:mask_graphics_76,x:346.234,y:94.08}).wait(1).to({graphics:mask_graphics_77,x:350.359,y:94.08}).wait(1).to({graphics:mask_graphics_78,x:354.484,y:94.08}).wait(1).to({graphics:mask_graphics_79,x:358.584,y:94.08}).wait(1).to({graphics:mask_graphics_80,x:362.684,y:94.08}).wait(1).to({graphics:mask_graphics_81,x:366.834,y:94.08}).wait(1).to({graphics:mask_graphics_82,x:370.934,y:94.105}).wait(1).to({graphics:mask_graphics_83,x:375.034,y:94.105}).wait(1).to({graphics:mask_graphics_84,x:379.159,y:94.105}).wait(1).to({graphics:mask_graphics_85,x:383.284,y:94.105}).wait(1).to({graphics:mask_graphics_86,x:387.384,y:94.105}).wait(1).to({graphics:mask_graphics_87,x:391.509,y:94.13}).wait(1).to({graphics:mask_graphics_88,x:395.634,y:94.13}).wait(1).to({graphics:mask_graphics_89,x:399.709,y:94.105}).wait(311));

	// bird1_obj_
	this.bird1 = new lib.Scene_1_bird1();
	this.bird1.name = "bird1";
	this.bird1.setTransform(-0.1,154.6,1.5284,1.5284,0,0,0,269,102.6);
	this.bird1.depth = 0;
	this.bird1.isAttachedToCamera = 0
	this.bird1.isAttachedToMask = 0
	this.bird1.layerDepth = 0
	this.bird1.layerIndex = 8
	this.bird1.maskLayerName = 0

	var maskedShapeInstanceList = [this.bird1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.bird1).to({regX:159.1,regY:123.2,scaleX:1.2566,scaleY:1.2566,y:154.65},14).to({regX:41.3,regY:145.3,scaleX:1.0555,scaleY:1.0555},15).to({regX:2,regY:152.5,scaleX:1.002,scaleY:1.002,x:-0.15},15).wait(45).to({_off:true},1).wait(310));

	// car_obj_
	this.car = new lib.Scene_1_car();
	this.car.name = "car";
	this.car.setTransform(663.35,410.9,1.5284,1.5284,0,0,0,703.1,270.3);
	this.car.depth = 0;
	this.car.isAttachedToCamera = 0
	this.car.isAttachedToMask = 0
	this.car.layerDepth = 0
	this.car.layerIndex = 9
	this.car.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.car).to({_off:true},90).wait(310));

	// road_obj_
	this.road = new lib.Scene_1_road();
	this.road.name = "road";
	this.road.setTransform(235.55,272.75,1.5284,1.5284,0,0,0,423.2,179.9);
	this.road.depth = 0;
	this.road.isAttachedToCamera = 0
	this.road.isAttachedToMask = 0
	this.road.layerDepth = 0
	this.road.layerIndex = 10
	this.road.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.road).to({regX:237.1,regY:270.4,scaleX:1.002,scaleY:1.002,x:235.4,y:272.8},89).to({_off:true},1).wait(310));

	// sky2_obj_
	this.sky2 = new lib.Scene_1_sky2();
	this.sky2.name = "sky2";
	this.sky2.setTransform(434.1,250,1.5284,1.5284,0,0,0,553.1,165);
	this.sky2.depth = 0;
	this.sky2.isAttachedToCamera = 0
	this.sky2.isAttachedToMask = 0
	this.sky2.layerDepth = 0
	this.sky2.layerIndex = 11
	this.sky2.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.sky2).to({_off:true},90).wait(310));

	// SunMoon_obj_
	this.SunMoon = new lib.Scene_1_SunMoon();
	this.SunMoon.name = "SunMoon";
	this.SunMoon.setTransform(0.05,-0.05,1.5284,1.5284,0,0,0,269.1,1.4);
	this.SunMoon.depth = 0;
	this.SunMoon.isAttachedToCamera = 0
	this.SunMoon.isAttachedToMask = 0
	this.SunMoon.layerDepth = 0
	this.SunMoon.layerIndex = 12
	this.SunMoon.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.SunMoon).wait(99).to({regX:0,regY:0,scaleX:1,scaleY:1,x:57.35,y:125.5},0).wait(98).to({x:0,y:0},1).wait(1).to({x:57.35,y:125.5},0).wait(83).to({x:0,y:0},1).to({_off:true},1).wait(116));

	// Mask (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_99 = new cjs.Graphics().moveTo(-91.3,106).lineTo(-91.3,-106).lineTo(91.3,-106).lineTo(91.3,106).closePath();
	var mask_1_graphics_100 = new cjs.Graphics().moveTo(-91.3,106).lineTo(-91.3,-106).lineTo(91.3,-106).lineTo(91.3,106).closePath();
	var mask_1_graphics_101 = new cjs.Graphics().moveTo(-91.3,106).lineTo(-91.3,-106).lineTo(91.3,-106).lineTo(91.3,106).closePath();
	var mask_1_graphics_102 = new cjs.Graphics().moveTo(-91.3,106).lineTo(-91.3,-106).lineTo(91.3,-106).lineTo(91.3,106).closePath();
	var mask_1_graphics_103 = new cjs.Graphics().moveTo(-91.3,106).lineTo(-91.3,-106).lineTo(91.3,-106).lineTo(91.3,106).closePath();
	var mask_1_graphics_104 = new cjs.Graphics().moveTo(-91.3,106).lineTo(-91.3,-106).lineTo(91.3,-106).lineTo(91.3,106).closePath();
	var mask_1_graphics_105 = new cjs.Graphics().moveTo(-91.3,106).lineTo(-91.3,-106).lineTo(91.3,-106).lineTo(91.3,106).closePath();
	var mask_1_graphics_106 = new cjs.Graphics().moveTo(-91.3,106).lineTo(-91.3,-106).lineTo(91.3,-106).lineTo(91.3,106).closePath();
	var mask_1_graphics_107 = new cjs.Graphics().moveTo(-91.3,106).lineTo(-91.3,-106).lineTo(91.3,-106).lineTo(91.3,106).closePath();
	var mask_1_graphics_108 = new cjs.Graphics().moveTo(-91.3,106).lineTo(-91.3,-106).lineTo(91.3,-106).lineTo(91.3,106).closePath();
	var mask_1_graphics_109 = new cjs.Graphics().moveTo(-91.3,106).lineTo(-91.3,-106).lineTo(91.3,-106).lineTo(91.3,106).closePath();
	var mask_1_graphics_110 = new cjs.Graphics().moveTo(-91.3,106).lineTo(-91.3,-106).lineTo(91.3,-106).lineTo(91.3,106).closePath();
	var mask_1_graphics_111 = new cjs.Graphics().moveTo(-91.3,106).lineTo(-91.3,-106).lineTo(91.3,-106).lineTo(91.3,106).closePath();
	var mask_1_graphics_112 = new cjs.Graphics().moveTo(-91.3,106).lineTo(-91.3,-106).lineTo(91.3,-106).lineTo(91.3,106).closePath();
	var mask_1_graphics_113 = new cjs.Graphics().moveTo(-91.3,106).lineTo(-91.3,-106).lineTo(91.3,-106).lineTo(91.3,106).closePath();
	var mask_1_graphics_114 = new cjs.Graphics().moveTo(-91.3,106).lineTo(-91.3,-106).lineTo(91.3,-106).lineTo(91.3,106).closePath();
	var mask_1_graphics_115 = new cjs.Graphics().moveTo(-91.3,106).lineTo(-91.3,-106).lineTo(91.3,-106).lineTo(91.3,106).closePath();
	var mask_1_graphics_116 = new cjs.Graphics().moveTo(-91.3,106).lineTo(-91.3,-106).lineTo(91.3,-106).lineTo(91.3,106).closePath();
	var mask_1_graphics_117 = new cjs.Graphics().moveTo(-91.3,106).lineTo(-91.3,-106).lineTo(91.3,-106).lineTo(91.3,106).closePath();
	var mask_1_graphics_118 = new cjs.Graphics().moveTo(-91.3,106).lineTo(-91.3,-106).lineTo(91.3,-106).lineTo(91.3,106).closePath();
	var mask_1_graphics_119 = new cjs.Graphics().moveTo(-91.3,106).lineTo(-91.3,-106).lineTo(91.3,-106).lineTo(91.3,106).closePath();
	var mask_1_graphics_120 = new cjs.Graphics().moveTo(-91.3,106).lineTo(-91.3,-106).lineTo(91.3,-106).lineTo(91.3,106).closePath();
	var mask_1_graphics_121 = new cjs.Graphics().moveTo(-91.3,106).lineTo(-91.3,-106).lineTo(91.3,-106).lineTo(91.3,106).closePath();
	var mask_1_graphics_122 = new cjs.Graphics().moveTo(-91.3,106).lineTo(-91.3,-106).lineTo(91.3,-106).lineTo(91.3,106).closePath();
	var mask_1_graphics_123 = new cjs.Graphics().moveTo(-91.3,106).lineTo(-91.3,-106).lineTo(91.3,-106).lineTo(91.3,106).closePath();
	var mask_1_graphics_124 = new cjs.Graphics().moveTo(-91.3,106).lineTo(-91.3,-106).lineTo(91.3,-106).lineTo(91.3,106).closePath();
	var mask_1_graphics_125 = new cjs.Graphics().moveTo(-91.3,106).lineTo(-91.3,-106).lineTo(91.3,-106).lineTo(91.3,106).closePath();
	var mask_1_graphics_126 = new cjs.Graphics().moveTo(-91.3,106).lineTo(-91.3,-106).lineTo(91.3,-106).lineTo(91.3,106).closePath();
	var mask_1_graphics_127 = new cjs.Graphics().moveTo(-91.3,106).lineTo(-91.3,-106).lineTo(91.3,-106).lineTo(91.3,106).closePath();
	var mask_1_graphics_128 = new cjs.Graphics().moveTo(-91.3,106).lineTo(-91.3,-106).lineTo(91.3,-106).lineTo(91.3,106).closePath();
	var mask_1_graphics_129 = new cjs.Graphics().moveTo(-91.3,106).lineTo(-91.3,-106).lineTo(91.3,-106).lineTo(91.3,106).closePath();
	var mask_1_graphics_130 = new cjs.Graphics().moveTo(-91.3,106).lineTo(-91.3,-106).lineTo(91.3,-106).lineTo(91.3,106).closePath();
	var mask_1_graphics_131 = new cjs.Graphics().moveTo(-91.3,106).lineTo(-91.3,-106).lineTo(91.3,-106).lineTo(91.3,106).closePath();
	var mask_1_graphics_132 = new cjs.Graphics().moveTo(-91.3,106).lineTo(-91.3,-106).lineTo(91.3,-106).lineTo(91.3,106).closePath();
	var mask_1_graphics_133 = new cjs.Graphics().moveTo(-91.3,106).lineTo(-91.3,-106).lineTo(91.3,-106).lineTo(91.3,106).closePath();
	var mask_1_graphics_134 = new cjs.Graphics().moveTo(-91.3,106).lineTo(-91.3,-106).lineTo(91.3,-106).lineTo(91.3,106).closePath();
	var mask_1_graphics_135 = new cjs.Graphics().moveTo(-91.3,106).lineTo(-91.3,-106).lineTo(91.3,-106).lineTo(91.3,106).closePath();
	var mask_1_graphics_136 = new cjs.Graphics().moveTo(-91.3,106).lineTo(-91.3,-106).lineTo(91.3,-106).lineTo(91.3,106).closePath();
	var mask_1_graphics_137 = new cjs.Graphics().moveTo(-91.3,106).lineTo(-91.3,-106).lineTo(91.3,-106).lineTo(91.3,106).closePath();
	var mask_1_graphics_138 = new cjs.Graphics().moveTo(-91.3,106).lineTo(-91.3,-106).lineTo(91.3,-106).lineTo(91.3,106).closePath();
	var mask_1_graphics_139 = new cjs.Graphics().moveTo(-91.3,106).lineTo(-91.3,-106).lineTo(91.3,-106).lineTo(91.3,106).closePath();
	var mask_1_graphics_140 = new cjs.Graphics().moveTo(-91.3,106).lineTo(-91.3,-106).lineTo(91.3,-106).lineTo(91.3,106).closePath();
	var mask_1_graphics_141 = new cjs.Graphics().moveTo(-91.3,106).lineTo(-91.3,-106).lineTo(91.3,-106).lineTo(91.3,106).closePath();
	var mask_1_graphics_142 = new cjs.Graphics().moveTo(-91.3,106).lineTo(-91.3,-106).lineTo(91.3,-106).lineTo(91.3,106).closePath();
	var mask_1_graphics_143 = new cjs.Graphics().moveTo(-91.3,106).lineTo(-91.3,-106).lineTo(91.3,-106).lineTo(91.3,106).closePath();
	var mask_1_graphics_144 = new cjs.Graphics().moveTo(-91.3,106).lineTo(-91.3,-106).lineTo(91.3,-106).lineTo(91.3,106).closePath();
	var mask_1_graphics_145 = new cjs.Graphics().moveTo(-91.3,106).lineTo(-91.3,-106).lineTo(91.3,-106).lineTo(91.3,106).closePath();
	var mask_1_graphics_146 = new cjs.Graphics().moveTo(-91.3,106).lineTo(-91.3,-106).lineTo(91.3,-106).lineTo(91.3,106).closePath();
	var mask_1_graphics_147 = new cjs.Graphics().moveTo(-91.3,106).lineTo(-91.3,-106).lineTo(91.3,-106).lineTo(91.3,106).closePath();
	var mask_1_graphics_148 = new cjs.Graphics().moveTo(-91.3,106).lineTo(-91.3,-106).lineTo(91.3,-106).lineTo(91.3,106).closePath();
	var mask_1_graphics_149 = new cjs.Graphics().moveTo(-91.3,106).lineTo(-91.3,-106).lineTo(91.3,-106).lineTo(91.3,106).closePath();
	var mask_1_graphics_150 = new cjs.Graphics().moveTo(-91.3,106).lineTo(-91.3,-106).lineTo(91.3,-106).lineTo(91.3,106).closePath();
	var mask_1_graphics_151 = new cjs.Graphics().moveTo(-91.3,106).lineTo(-91.3,-106).lineTo(91.3,-106).lineTo(91.3,106).closePath();
	var mask_1_graphics_152 = new cjs.Graphics().moveTo(-91.3,106).lineTo(-91.3,-106).lineTo(91.3,-106).lineTo(91.3,106).closePath();
	var mask_1_graphics_153 = new cjs.Graphics().moveTo(-91.3,106).lineTo(-91.3,-106).lineTo(91.3,-106).lineTo(91.3,106).closePath();
	var mask_1_graphics_154 = new cjs.Graphics().moveTo(-91.3,106).lineTo(-91.3,-106).lineTo(91.3,-106).lineTo(91.3,106).closePath();
	var mask_1_graphics_155 = new cjs.Graphics().moveTo(-91.3,106).lineTo(-91.3,-106).lineTo(91.3,-106).lineTo(91.3,106).closePath();
	var mask_1_graphics_156 = new cjs.Graphics().moveTo(-91.3,106).lineTo(-91.3,-106).lineTo(91.3,-106).lineTo(91.3,106).closePath();
	var mask_1_graphics_157 = new cjs.Graphics().moveTo(-91.3,106).lineTo(-91.3,-106).lineTo(91.3,-106).lineTo(91.3,106).closePath();
	var mask_1_graphics_158 = new cjs.Graphics().moveTo(-91.3,106).lineTo(-91.3,-106).lineTo(91.3,-106).lineTo(91.3,106).closePath();
	var mask_1_graphics_159 = new cjs.Graphics().moveTo(-91.3,106).lineTo(-91.3,-106).lineTo(91.3,-106).lineTo(91.3,106).closePath();
	var mask_1_graphics_160 = new cjs.Graphics().moveTo(-91.3,106).lineTo(-91.3,-106).lineTo(91.3,-106).lineTo(91.3,106).closePath();
	var mask_1_graphics_161 = new cjs.Graphics().moveTo(-91.3,106).lineTo(-91.3,-106).lineTo(91.3,-106).lineTo(91.3,106).closePath();
	var mask_1_graphics_162 = new cjs.Graphics().moveTo(-91.3,106).lineTo(-91.3,-106).lineTo(91.3,-106).lineTo(91.3,106).closePath();
	var mask_1_graphics_163 = new cjs.Graphics().moveTo(-91.3,106).lineTo(-91.3,-106).lineTo(91.3,-106).lineTo(91.3,106).closePath();
	var mask_1_graphics_164 = new cjs.Graphics().moveTo(-91.3,106).lineTo(-91.3,-106).lineTo(91.3,-106).lineTo(91.3,106).closePath();
	var mask_1_graphics_165 = new cjs.Graphics().moveTo(-91.3,106).lineTo(-91.3,-106).lineTo(91.3,-106).lineTo(91.3,106).closePath();
	var mask_1_graphics_166 = new cjs.Graphics().moveTo(-91.3,106).lineTo(-91.3,-106).lineTo(91.3,-106).lineTo(91.3,106).closePath();
	var mask_1_graphics_167 = new cjs.Graphics().moveTo(-91.3,106).lineTo(-91.3,-106).lineTo(91.3,-106).lineTo(91.3,106).closePath();
	var mask_1_graphics_168 = new cjs.Graphics().moveTo(-91.3,106).lineTo(-91.3,-106).lineTo(91.3,-106).lineTo(91.3,106).closePath();
	var mask_1_graphics_169 = new cjs.Graphics().moveTo(-91.3,106).lineTo(-91.3,-106).lineTo(91.3,-106).lineTo(91.3,106).closePath();
	var mask_1_graphics_170 = new cjs.Graphics().moveTo(-91.3,106).lineTo(-91.3,-106).lineTo(91.3,-106).lineTo(91.3,106).closePath();
	var mask_1_graphics_171 = new cjs.Graphics().moveTo(-91.3,106).lineTo(-91.3,-106).lineTo(91.3,-106).lineTo(91.3,106).closePath();
	var mask_1_graphics_172 = new cjs.Graphics().moveTo(-91.3,106).lineTo(-91.3,-106).lineTo(91.3,-106).lineTo(91.3,106).closePath();
	var mask_1_graphics_173 = new cjs.Graphics().moveTo(-91.3,106).lineTo(-91.3,-106).lineTo(91.3,-106).lineTo(91.3,106).closePath();
	var mask_1_graphics_174 = new cjs.Graphics().moveTo(-91.3,106).lineTo(-91.3,-106).lineTo(91.3,-106).lineTo(91.3,106).closePath();
	var mask_1_graphics_175 = new cjs.Graphics().moveTo(-91.3,106).lineTo(-91.3,-106).lineTo(91.3,-106).lineTo(91.3,106).closePath();
	var mask_1_graphics_176 = new cjs.Graphics().moveTo(-91.3,106).lineTo(-91.3,-106).lineTo(91.3,-106).lineTo(91.3,106).closePath();
	var mask_1_graphics_177 = new cjs.Graphics().moveTo(-91.3,106).lineTo(-91.3,-106).lineTo(91.3,-106).lineTo(91.3,106).closePath();
	var mask_1_graphics_178 = new cjs.Graphics().moveTo(-91.3,106).lineTo(-91.3,-106).lineTo(91.3,-106).lineTo(91.3,106).closePath();
	var mask_1_graphics_179 = new cjs.Graphics().moveTo(-91.3,106).lineTo(-91.3,-106).lineTo(91.3,-106).lineTo(91.3,106).closePath();
	var mask_1_graphics_180 = new cjs.Graphics().moveTo(-91.3,106).lineTo(-91.3,-106).lineTo(91.3,-106).lineTo(91.3,106).closePath();
	var mask_1_graphics_181 = new cjs.Graphics().moveTo(-91.3,106).lineTo(-91.3,-106).lineTo(91.3,-106).lineTo(91.3,106).closePath();
	var mask_1_graphics_182 = new cjs.Graphics().moveTo(-91.3,106).lineTo(-91.3,-106).lineTo(91.3,-106).lineTo(91.3,106).closePath();
	var mask_1_graphics_183 = new cjs.Graphics().moveTo(-91.3,106).lineTo(-91.3,-106).lineTo(91.3,-106).lineTo(91.3,106).closePath();
	var mask_1_graphics_184 = new cjs.Graphics().moveTo(-91.3,106).lineTo(-91.3,-106).lineTo(91.3,-106).lineTo(91.3,106).closePath();
	var mask_1_graphics_185 = new cjs.Graphics().moveTo(-91.3,106).lineTo(-91.3,-106).lineTo(91.3,-106).lineTo(91.3,106).closePath();
	var mask_1_graphics_186 = new cjs.Graphics().moveTo(-91.3,106).lineTo(-91.3,-106).lineTo(91.3,-106).lineTo(91.3,106).closePath();
	var mask_1_graphics_187 = new cjs.Graphics().moveTo(-91.3,106).lineTo(-91.3,-106).lineTo(91.3,-106).lineTo(91.3,106).closePath();
	var mask_1_graphics_188 = new cjs.Graphics().moveTo(-91.3,106).lineTo(-91.3,-106).lineTo(91.3,-106).lineTo(91.3,106).closePath();
	var mask_1_graphics_189 = new cjs.Graphics().moveTo(-91.3,106).lineTo(-91.3,-106).lineTo(91.3,-106).lineTo(91.3,106).closePath();
	var mask_1_graphics_190 = new cjs.Graphics().moveTo(-91.3,106).lineTo(-91.3,-106).lineTo(91.3,-106).lineTo(91.3,106).closePath();
	var mask_1_graphics_191 = new cjs.Graphics().moveTo(-91.3,106).lineTo(-91.3,-106).lineTo(91.3,-106).lineTo(91.3,106).closePath();
	var mask_1_graphics_192 = new cjs.Graphics().moveTo(-91.3,106).lineTo(-91.3,-106).lineTo(91.3,-106).lineTo(91.3,106).closePath();
	var mask_1_graphics_193 = new cjs.Graphics().moveTo(-91.3,106).lineTo(-91.3,-106).lineTo(91.3,-106).lineTo(91.3,106).closePath();
	var mask_1_graphics_194 = new cjs.Graphics().moveTo(-91.3,106).lineTo(-91.3,-106).lineTo(91.3,-106).lineTo(91.3,106).closePath();
	var mask_1_graphics_195 = new cjs.Graphics().moveTo(-91.3,106).lineTo(-91.3,-106).lineTo(91.3,-106).lineTo(91.3,106).closePath();
	var mask_1_graphics_196 = new cjs.Graphics().moveTo(-91.3,106).lineTo(-91.3,-106).lineTo(91.3,-106).lineTo(91.3,106).closePath();
	var mask_1_graphics_197 = new cjs.Graphics().moveTo(-91.3,106).lineTo(-91.3,-106).lineTo(91.3,-106).lineTo(91.3,106).closePath();
	var mask_1_graphics_198 = new cjs.Graphics().moveTo(-91.3,106).lineTo(-91.3,-106).lineTo(91.3,-106).lineTo(91.3,106).closePath();
	var mask_1_graphics_199 = new cjs.Graphics().moveTo(-91.3,106).lineTo(-91.3,-106).lineTo(91.3,-106).lineTo(91.3,106).closePath();
	var mask_1_graphics_200 = new cjs.Graphics().moveTo(-91.3,106).lineTo(-91.3,-106).lineTo(91.3,-106).lineTo(91.3,106).closePath();
	var mask_1_graphics_201 = new cjs.Graphics().moveTo(-91.3,106).lineTo(-91.3,-106).lineTo(91.3,-106).lineTo(91.3,106).closePath();
	var mask_1_graphics_202 = new cjs.Graphics().moveTo(-91.3,106).lineTo(-91.3,-106).lineTo(91.3,-106).lineTo(91.3,106).closePath();
	var mask_1_graphics_203 = new cjs.Graphics().moveTo(-91.3,106).lineTo(-91.3,-106).lineTo(91.3,-106).lineTo(91.3,106).closePath();
	var mask_1_graphics_204 = new cjs.Graphics().moveTo(-91.3,106).lineTo(-91.3,-106).lineTo(91.3,-106).lineTo(91.3,106).closePath();
	var mask_1_graphics_205 = new cjs.Graphics().moveTo(-91.3,106).lineTo(-91.3,-106).lineTo(91.3,-106).lineTo(91.3,106).closePath();
	var mask_1_graphics_206 = new cjs.Graphics().moveTo(-91.3,106).lineTo(-91.3,-106).lineTo(91.3,-106).lineTo(91.3,106).closePath();
	var mask_1_graphics_207 = new cjs.Graphics().moveTo(-91.3,106).lineTo(-91.3,-106).lineTo(91.3,-106).lineTo(91.3,106).closePath();
	var mask_1_graphics_208 = new cjs.Graphics().moveTo(-91.3,106).lineTo(-91.3,-106).lineTo(91.3,-106).lineTo(91.3,106).closePath();
	var mask_1_graphics_209 = new cjs.Graphics().moveTo(-91.3,106).lineTo(-91.3,-106).lineTo(91.3,-106).lineTo(91.3,106).closePath();
	var mask_1_graphics_210 = new cjs.Graphics().moveTo(-91.3,106).lineTo(-91.3,-106).lineTo(91.3,-106).lineTo(91.3,106).closePath();
	var mask_1_graphics_211 = new cjs.Graphics().moveTo(-91.3,106).lineTo(-91.3,-106).lineTo(91.3,-106).lineTo(91.3,106).closePath();
	var mask_1_graphics_212 = new cjs.Graphics().moveTo(-91.3,106).lineTo(-91.3,-106).lineTo(91.3,-106).lineTo(91.3,106).closePath();
	var mask_1_graphics_213 = new cjs.Graphics().moveTo(-91.3,106).lineTo(-91.3,-106).lineTo(91.3,-106).lineTo(91.3,106).closePath();
	var mask_1_graphics_214 = new cjs.Graphics().moveTo(-91.3,106).lineTo(-91.3,-106).lineTo(91.3,-106).lineTo(91.3,106).closePath();
	var mask_1_graphics_215 = new cjs.Graphics().moveTo(-91.3,106).lineTo(-91.3,-106).lineTo(91.3,-106).lineTo(91.3,106).closePath();
	var mask_1_graphics_216 = new cjs.Graphics().moveTo(-91.3,106).lineTo(-91.3,-106).lineTo(91.3,-106).lineTo(91.3,106).closePath();
	var mask_1_graphics_217 = new cjs.Graphics().moveTo(-91.3,106).lineTo(-91.3,-106).lineTo(91.3,-106).lineTo(91.3,106).closePath();
	var mask_1_graphics_218 = new cjs.Graphics().moveTo(-91.3,106).lineTo(-91.3,-106).lineTo(91.3,-106).lineTo(91.3,106).closePath();
	var mask_1_graphics_219 = new cjs.Graphics().moveTo(-91.3,106).lineTo(-91.3,-106).lineTo(91.3,-106).lineTo(91.3,106).closePath();
	var mask_1_graphics_220 = new cjs.Graphics().moveTo(-91.3,106).lineTo(-91.3,-106).lineTo(91.3,-106).lineTo(91.3,106).closePath();
	var mask_1_graphics_221 = new cjs.Graphics().moveTo(-91.3,106).lineTo(-91.3,-106).lineTo(91.3,-106).lineTo(91.3,106).closePath();
	var mask_1_graphics_222 = new cjs.Graphics().moveTo(-91.3,106).lineTo(-91.3,-106).lineTo(91.3,-106).lineTo(91.3,106).closePath();
	var mask_1_graphics_223 = new cjs.Graphics().moveTo(-91.3,106).lineTo(-91.3,-106).lineTo(91.3,-106).lineTo(91.3,106).closePath();
	var mask_1_graphics_224 = new cjs.Graphics().moveTo(-91.3,106).lineTo(-91.3,-106).lineTo(91.3,-106).lineTo(91.3,106).closePath();
	var mask_1_graphics_225 = new cjs.Graphics().moveTo(-91.3,106).lineTo(-91.3,-106).lineTo(91.3,-106).lineTo(91.3,106).closePath();
	var mask_1_graphics_226 = new cjs.Graphics().moveTo(-91.3,106).lineTo(-91.3,-106).lineTo(91.3,-106).lineTo(91.3,106).closePath();
	var mask_1_graphics_227 = new cjs.Graphics().moveTo(-91.3,106).lineTo(-91.3,-106).lineTo(91.3,-106).lineTo(91.3,106).closePath();
	var mask_1_graphics_228 = new cjs.Graphics().moveTo(-91.3,106).lineTo(-91.3,-106).lineTo(91.3,-106).lineTo(91.3,106).closePath();
	var mask_1_graphics_229 = new cjs.Graphics().moveTo(-91.3,106).lineTo(-91.3,-106).lineTo(91.3,-106).lineTo(91.3,106).closePath();
	var mask_1_graphics_230 = new cjs.Graphics().moveTo(-91.3,106).lineTo(-91.3,-106).lineTo(91.3,-106).lineTo(91.3,106).closePath();
	var mask_1_graphics_231 = new cjs.Graphics().moveTo(-91.3,106).lineTo(-91.3,-106).lineTo(91.3,-106).lineTo(91.3,106).closePath();
	var mask_1_graphics_232 = new cjs.Graphics().moveTo(-91.3,106).lineTo(-91.3,-106).lineTo(91.3,-106).lineTo(91.3,106).closePath();
	var mask_1_graphics_233 = new cjs.Graphics().moveTo(-91.3,106).lineTo(-91.3,-106).lineTo(91.3,-106).lineTo(91.3,106).closePath();
	var mask_1_graphics_234 = new cjs.Graphics().moveTo(-91.3,106).lineTo(-91.3,-106).lineTo(91.3,-106).lineTo(91.3,106).closePath();
	var mask_1_graphics_235 = new cjs.Graphics().moveTo(-91.3,106).lineTo(-91.3,-106).lineTo(91.3,-106).lineTo(91.3,106).closePath();
	var mask_1_graphics_236 = new cjs.Graphics().moveTo(-91.3,106).lineTo(-91.3,-106).lineTo(91.3,-106).lineTo(91.3,106).closePath();
	var mask_1_graphics_237 = new cjs.Graphics().moveTo(-91.3,106).lineTo(-91.3,-106).lineTo(91.3,-106).lineTo(91.3,106).closePath();
	var mask_1_graphics_238 = new cjs.Graphics().moveTo(-91.3,106).lineTo(-91.3,-106).lineTo(91.3,-106).lineTo(91.3,106).closePath();
	var mask_1_graphics_239 = new cjs.Graphics().moveTo(-91.3,106).lineTo(-91.3,-106).lineTo(91.3,-106).lineTo(91.3,106).closePath();
	var mask_1_graphics_240 = new cjs.Graphics().moveTo(-91.3,106).lineTo(-91.3,-106).lineTo(91.3,-106).lineTo(91.3,106).closePath();
	var mask_1_graphics_241 = new cjs.Graphics().moveTo(-91.3,106).lineTo(-91.3,-106).lineTo(91.3,-106).lineTo(91.3,106).closePath();
	var mask_1_graphics_242 = new cjs.Graphics().moveTo(-91.3,106).lineTo(-91.3,-106).lineTo(91.3,-106).lineTo(91.3,106).closePath();
	var mask_1_graphics_243 = new cjs.Graphics().moveTo(-91.3,106).lineTo(-91.3,-106).lineTo(91.3,-106).lineTo(91.3,106).closePath();
	var mask_1_graphics_244 = new cjs.Graphics().moveTo(-91.3,106).lineTo(-91.3,-106).lineTo(91.3,-106).lineTo(91.3,106).closePath();
	var mask_1_graphics_245 = new cjs.Graphics().moveTo(-91.3,106).lineTo(-91.3,-106).lineTo(91.3,-106).lineTo(91.3,106).closePath();
	var mask_1_graphics_246 = new cjs.Graphics().moveTo(-91.3,106).lineTo(-91.3,-106).lineTo(91.3,-106).lineTo(91.3,106).closePath();
	var mask_1_graphics_247 = new cjs.Graphics().moveTo(-91.3,106).lineTo(-91.3,-106).lineTo(91.3,-106).lineTo(91.3,106).closePath();
	var mask_1_graphics_248 = new cjs.Graphics().moveTo(-91.3,106).lineTo(-91.3,-106).lineTo(91.3,-106).lineTo(91.3,106).closePath();
	var mask_1_graphics_249 = new cjs.Graphics().moveTo(-91.3,106).lineTo(-91.3,-106).lineTo(91.3,-106).lineTo(91.3,106).closePath();
	var mask_1_graphics_250 = new cjs.Graphics().moveTo(-91.3,106).lineTo(-91.3,-106).lineTo(91.3,-106).lineTo(91.3,106).closePath();
	var mask_1_graphics_251 = new cjs.Graphics().moveTo(-91.3,106).lineTo(-91.3,-106).lineTo(91.3,-106).lineTo(91.3,106).closePath();
	var mask_1_graphics_252 = new cjs.Graphics().moveTo(-91.3,106).lineTo(-91.3,-106).lineTo(91.3,-106).lineTo(91.3,106).closePath();
	var mask_1_graphics_253 = new cjs.Graphics().moveTo(-91.3,106).lineTo(-91.3,-106).lineTo(91.3,-106).lineTo(91.3,106).closePath();
	var mask_1_graphics_254 = new cjs.Graphics().moveTo(-91.3,106).lineTo(-91.3,-106).lineTo(91.3,-106).lineTo(91.3,106).closePath();
	var mask_1_graphics_255 = new cjs.Graphics().moveTo(-91.3,106).lineTo(-91.3,-106).lineTo(91.3,-106).lineTo(91.3,106).closePath();
	var mask_1_graphics_256 = new cjs.Graphics().moveTo(-91.3,106).lineTo(-91.3,-106).lineTo(91.3,-106).lineTo(91.3,106).closePath();
	var mask_1_graphics_257 = new cjs.Graphics().moveTo(-91.3,106).lineTo(-91.3,-106).lineTo(91.3,-106).lineTo(91.3,106).closePath();
	var mask_1_graphics_258 = new cjs.Graphics().moveTo(-91.3,106).lineTo(-91.3,-106).lineTo(91.3,-106).lineTo(91.3,106).closePath();
	var mask_1_graphics_259 = new cjs.Graphics().moveTo(-91.3,106).lineTo(-91.3,-106).lineTo(91.3,-106).lineTo(91.3,106).closePath();
	var mask_1_graphics_260 = new cjs.Graphics().moveTo(-91.3,106).lineTo(-91.3,-106).lineTo(91.3,-106).lineTo(91.3,106).closePath();
	var mask_1_graphics_261 = new cjs.Graphics().moveTo(-91.3,106).lineTo(-91.3,-106).lineTo(91.3,-106).lineTo(91.3,106).closePath();
	var mask_1_graphics_262 = new cjs.Graphics().moveTo(-91.3,106).lineTo(-91.3,-106).lineTo(91.3,-106).lineTo(91.3,106).closePath();
	var mask_1_graphics_263 = new cjs.Graphics().moveTo(-91.3,106).lineTo(-91.3,-106).lineTo(91.3,-106).lineTo(91.3,106).closePath();
	var mask_1_graphics_264 = new cjs.Graphics().moveTo(-91.3,106).lineTo(-91.3,-106).lineTo(91.3,-106).lineTo(91.3,106).closePath();
	var mask_1_graphics_265 = new cjs.Graphics().moveTo(-91.3,106).lineTo(-91.3,-106).lineTo(91.3,-106).lineTo(91.3,106).closePath();
	var mask_1_graphics_266 = new cjs.Graphics().moveTo(-91.3,106).lineTo(-91.3,-106).lineTo(91.3,-106).lineTo(91.3,106).closePath();
	var mask_1_graphics_267 = new cjs.Graphics().moveTo(-91.3,106).lineTo(-91.3,-106).lineTo(91.3,-106).lineTo(91.3,106).closePath();
	var mask_1_graphics_268 = new cjs.Graphics().moveTo(-91.3,106).lineTo(-91.3,-106).lineTo(91.3,-106).lineTo(91.3,106).closePath();
	var mask_1_graphics_269 = new cjs.Graphics().moveTo(-91.3,106).lineTo(-91.3,-106).lineTo(91.3,-106).lineTo(91.3,106).closePath();
	var mask_1_graphics_270 = new cjs.Graphics().moveTo(-91.3,106).lineTo(-91.3,-106).lineTo(91.3,-106).lineTo(91.3,106).closePath();
	var mask_1_graphics_271 = new cjs.Graphics().moveTo(-91.3,106).lineTo(-91.3,-106).lineTo(91.3,-106).lineTo(91.3,106).closePath();
	var mask_1_graphics_272 = new cjs.Graphics().moveTo(-91.3,106).lineTo(-91.3,-106).lineTo(91.3,-106).lineTo(91.3,106).closePath();
	var mask_1_graphics_273 = new cjs.Graphics().moveTo(-91.3,106).lineTo(-91.3,-106).lineTo(91.3,-106).lineTo(91.3,106).closePath();
	var mask_1_graphics_274 = new cjs.Graphics().moveTo(-91.3,106).lineTo(-91.3,-106).lineTo(91.3,-106).lineTo(91.3,106).closePath();
	var mask_1_graphics_275 = new cjs.Graphics().moveTo(-91.3,106).lineTo(-91.3,-106).lineTo(91.3,-106).lineTo(91.3,106).closePath();
	var mask_1_graphics_276 = new cjs.Graphics().moveTo(-91.3,106).lineTo(-91.3,-106).lineTo(91.3,-106).lineTo(91.3,106).closePath();
	var mask_1_graphics_277 = new cjs.Graphics().moveTo(-91.3,106).lineTo(-91.3,-106).lineTo(91.3,-106).lineTo(91.3,106).closePath();
	var mask_1_graphics_278 = new cjs.Graphics().moveTo(-91.3,106).lineTo(-91.3,-106).lineTo(91.3,-106).lineTo(91.3,106).closePath();
	var mask_1_graphics_279 = new cjs.Graphics().moveTo(-91.3,106).lineTo(-91.3,-106).lineTo(91.3,-106).lineTo(91.3,106).closePath();
	var mask_1_graphics_280 = new cjs.Graphics().moveTo(-91.3,106).lineTo(-91.3,-106).lineTo(91.3,-106).lineTo(91.3,106).closePath();
	var mask_1_graphics_281 = new cjs.Graphics().moveTo(-91.3,106).lineTo(-91.3,-106).lineTo(91.3,-106).lineTo(91.3,106).closePath();
	var mask_1_graphics_282 = new cjs.Graphics().moveTo(-91.3,106).lineTo(-91.3,-106).lineTo(91.3,-106).lineTo(91.3,106).closePath();
	var mask_1_graphics_283 = new cjs.Graphics().moveTo(-91.3,106).lineTo(-91.3,-106).lineTo(91.3,-106).lineTo(91.3,106).closePath();

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:null,x:0,y:0}).wait(99).to({graphics:mask_1_graphics_99,x:512.6,y:365.7}).wait(1).to({graphics:mask_1_graphics_100,x:512.6,y:365.7}).wait(1).to({graphics:mask_1_graphics_101,x:512.6,y:365.7}).wait(1).to({graphics:mask_1_graphics_102,x:512.6,y:365.7}).wait(1).to({graphics:mask_1_graphics_103,x:512.6,y:365.7}).wait(1).to({graphics:mask_1_graphics_104,x:512.6,y:365.7}).wait(1).to({graphics:mask_1_graphics_105,x:512.6,y:365.7}).wait(1).to({graphics:mask_1_graphics_106,x:512.6,y:365.7}).wait(1).to({graphics:mask_1_graphics_107,x:512.6,y:365.7}).wait(1).to({graphics:mask_1_graphics_108,x:512.6,y:365.7}).wait(1).to({graphics:mask_1_graphics_109,x:512.6,y:365.7}).wait(1).to({graphics:mask_1_graphics_110,x:512.6,y:365.7}).wait(1).to({graphics:mask_1_graphics_111,x:512.6,y:365.7}).wait(1).to({graphics:mask_1_graphics_112,x:512.6,y:365.7}).wait(1).to({graphics:mask_1_graphics_113,x:512.6,y:365.7}).wait(1).to({graphics:mask_1_graphics_114,x:512.6,y:365.7}).wait(1).to({graphics:mask_1_graphics_115,x:512.6,y:365.7}).wait(1).to({graphics:mask_1_graphics_116,x:512.6,y:365.7}).wait(1).to({graphics:mask_1_graphics_117,x:512.6,y:365.7}).wait(1).to({graphics:mask_1_graphics_118,x:512.6,y:365.7}).wait(1).to({graphics:mask_1_graphics_119,x:512.6,y:365.7}).wait(1).to({graphics:mask_1_graphics_120,x:512.6,y:365.7}).wait(1).to({graphics:mask_1_graphics_121,x:512.6,y:365.7}).wait(1).to({graphics:mask_1_graphics_122,x:512.6,y:365.7}).wait(1).to({graphics:mask_1_graphics_123,x:512.6,y:365.7}).wait(1).to({graphics:mask_1_graphics_124,x:512.6,y:365.7}).wait(1).to({graphics:mask_1_graphics_125,x:512.6,y:365.7}).wait(1).to({graphics:mask_1_graphics_126,x:512.6,y:365.7}).wait(1).to({graphics:mask_1_graphics_127,x:512.6,y:365.7}).wait(1).to({graphics:mask_1_graphics_128,x:512.6,y:365.7}).wait(1).to({graphics:mask_1_graphics_129,x:512.6,y:365.7}).wait(1).to({graphics:mask_1_graphics_130,x:512.6,y:365.7}).wait(1).to({graphics:mask_1_graphics_131,x:512.6,y:365.7}).wait(1).to({graphics:mask_1_graphics_132,x:512.6,y:365.7}).wait(1).to({graphics:mask_1_graphics_133,x:512.6,y:365.7}).wait(1).to({graphics:mask_1_graphics_134,x:512.6,y:365.7}).wait(1).to({graphics:mask_1_graphics_135,x:512.6,y:365.7}).wait(1).to({graphics:mask_1_graphics_136,x:512.6,y:365.7}).wait(1).to({graphics:mask_1_graphics_137,x:512.6,y:365.7}).wait(1).to({graphics:mask_1_graphics_138,x:512.6,y:365.7}).wait(1).to({graphics:mask_1_graphics_139,x:512.6,y:365.7}).wait(1).to({graphics:mask_1_graphics_140,x:512.6,y:365.7}).wait(1).to({graphics:mask_1_graphics_141,x:512.6,y:365.7}).wait(1).to({graphics:mask_1_graphics_142,x:512.6,y:365.7}).wait(1).to({graphics:mask_1_graphics_143,x:512.6,y:365.7}).wait(1).to({graphics:mask_1_graphics_144,x:512.6,y:365.7}).wait(1).to({graphics:mask_1_graphics_145,x:512.6,y:365.7}).wait(1).to({graphics:mask_1_graphics_146,x:512.6,y:365.7}).wait(1).to({graphics:mask_1_graphics_147,x:512.6,y:365.7}).wait(1).to({graphics:mask_1_graphics_148,x:512.6,y:365.7}).wait(1).to({graphics:mask_1_graphics_149,x:512.6,y:365.7}).wait(1).to({graphics:mask_1_graphics_150,x:512.6,y:365.7}).wait(1).to({graphics:mask_1_graphics_151,x:512.6,y:365.7}).wait(1).to({graphics:mask_1_graphics_152,x:512.6,y:365.7}).wait(1).to({graphics:mask_1_graphics_153,x:512.6,y:365.7}).wait(1).to({graphics:mask_1_graphics_154,x:512.6,y:365.7}).wait(1).to({graphics:mask_1_graphics_155,x:512.6,y:365.7}).wait(1).to({graphics:mask_1_graphics_156,x:512.6,y:365.7}).wait(1).to({graphics:mask_1_graphics_157,x:512.6,y:365.7}).wait(1).to({graphics:mask_1_graphics_158,x:512.6,y:365.7}).wait(1).to({graphics:mask_1_graphics_159,x:512.6,y:365.7}).wait(1).to({graphics:mask_1_graphics_160,x:512.6,y:365.7}).wait(1).to({graphics:mask_1_graphics_161,x:512.6,y:365.7}).wait(1).to({graphics:mask_1_graphics_162,x:512.6,y:365.7}).wait(1).to({graphics:mask_1_graphics_163,x:512.6,y:365.7}).wait(1).to({graphics:mask_1_graphics_164,x:512.6,y:365.7}).wait(1).to({graphics:mask_1_graphics_165,x:512.6,y:365.7}).wait(1).to({graphics:mask_1_graphics_166,x:512.6,y:365.7}).wait(1).to({graphics:mask_1_graphics_167,x:512.6,y:365.7}).wait(1).to({graphics:mask_1_graphics_168,x:512.6,y:365.7}).wait(1).to({graphics:mask_1_graphics_169,x:512.6,y:365.7}).wait(1).to({graphics:mask_1_graphics_170,x:512.6,y:365.7}).wait(1).to({graphics:mask_1_graphics_171,x:512.6,y:365.7}).wait(1).to({graphics:mask_1_graphics_172,x:512.6,y:365.7}).wait(1).to({graphics:mask_1_graphics_173,x:512.6,y:365.7}).wait(1).to({graphics:mask_1_graphics_174,x:512.6,y:365.7}).wait(1).to({graphics:mask_1_graphics_175,x:512.6,y:365.7}).wait(1).to({graphics:mask_1_graphics_176,x:512.6,y:365.7}).wait(1).to({graphics:mask_1_graphics_177,x:512.6,y:365.7}).wait(1).to({graphics:mask_1_graphics_178,x:512.6,y:365.7}).wait(1).to({graphics:mask_1_graphics_179,x:512.6,y:365.7}).wait(1).to({graphics:mask_1_graphics_180,x:512.6,y:365.7}).wait(1).to({graphics:mask_1_graphics_181,x:512.6,y:365.7}).wait(1).to({graphics:mask_1_graphics_182,x:512.6,y:365.7}).wait(1).to({graphics:mask_1_graphics_183,x:512.6,y:365.7}).wait(1).to({graphics:mask_1_graphics_184,x:512.6,y:365.7}).wait(1).to({graphics:mask_1_graphics_185,x:512.6,y:365.7}).wait(1).to({graphics:mask_1_graphics_186,x:512.6,y:365.7}).wait(1).to({graphics:mask_1_graphics_187,x:512.6,y:365.7}).wait(1).to({graphics:mask_1_graphics_188,x:512.6,y:365.7}).wait(1).to({graphics:mask_1_graphics_189,x:512.6,y:365.7}).wait(1).to({graphics:mask_1_graphics_190,x:512.6,y:365.7}).wait(1).to({graphics:mask_1_graphics_191,x:512.6,y:365.7}).wait(1).to({graphics:mask_1_graphics_192,x:512.6,y:365.7}).wait(1).to({graphics:mask_1_graphics_193,x:512.6,y:365.7}).wait(1).to({graphics:mask_1_graphics_194,x:512.6,y:365.7}).wait(1).to({graphics:mask_1_graphics_195,x:512.6,y:365.7}).wait(1).to({graphics:mask_1_graphics_196,x:512.6,y:365.7}).wait(1).to({graphics:mask_1_graphics_197,x:512.6,y:365.7}).wait(1).to({graphics:mask_1_graphics_198,x:512.6,y:365.7}).wait(1).to({graphics:mask_1_graphics_199,x:512.6,y:365.7}).wait(1).to({graphics:mask_1_graphics_200,x:512.6,y:365.7}).wait(1).to({graphics:mask_1_graphics_201,x:512.6,y:365.7}).wait(1).to({graphics:mask_1_graphics_202,x:512.6,y:365.7}).wait(1).to({graphics:mask_1_graphics_203,x:512.6,y:365.7}).wait(1).to({graphics:mask_1_graphics_204,x:512.6,y:365.7}).wait(1).to({graphics:mask_1_graphics_205,x:512.6,y:365.7}).wait(1).to({graphics:mask_1_graphics_206,x:512.6,y:365.7}).wait(1).to({graphics:mask_1_graphics_207,x:512.6,y:365.7}).wait(1).to({graphics:mask_1_graphics_208,x:512.6,y:365.7}).wait(1).to({graphics:mask_1_graphics_209,x:512.6,y:365.7}).wait(1).to({graphics:mask_1_graphics_210,x:512.6,y:365.7}).wait(1).to({graphics:mask_1_graphics_211,x:512.6,y:365.7}).wait(1).to({graphics:mask_1_graphics_212,x:512.6,y:365.7}).wait(1).to({graphics:mask_1_graphics_213,x:512.6,y:365.7}).wait(1).to({graphics:mask_1_graphics_214,x:512.6,y:365.7}).wait(1).to({graphics:mask_1_graphics_215,x:512.6,y:365.7}).wait(1).to({graphics:mask_1_graphics_216,x:512.6,y:365.7}).wait(1).to({graphics:mask_1_graphics_217,x:512.6,y:365.7}).wait(1).to({graphics:mask_1_graphics_218,x:512.6,y:365.7}).wait(1).to({graphics:mask_1_graphics_219,x:512.6,y:365.7}).wait(1).to({graphics:mask_1_graphics_220,x:512.6,y:365.7}).wait(1).to({graphics:mask_1_graphics_221,x:512.6,y:365.7}).wait(1).to({graphics:mask_1_graphics_222,x:512.6,y:365.7}).wait(1).to({graphics:mask_1_graphics_223,x:512.6,y:365.7}).wait(1).to({graphics:mask_1_graphics_224,x:512.6,y:365.7}).wait(1).to({graphics:mask_1_graphics_225,x:512.6,y:365.7}).wait(1).to({graphics:mask_1_graphics_226,x:512.6,y:365.7}).wait(1).to({graphics:mask_1_graphics_227,x:512.6,y:365.7}).wait(1).to({graphics:mask_1_graphics_228,x:512.6,y:365.7}).wait(1).to({graphics:mask_1_graphics_229,x:512.6,y:365.7}).wait(1).to({graphics:mask_1_graphics_230,x:512.6,y:365.7}).wait(1).to({graphics:mask_1_graphics_231,x:512.6,y:365.7}).wait(1).to({graphics:mask_1_graphics_232,x:512.6,y:365.7}).wait(1).to({graphics:mask_1_graphics_233,x:512.6,y:365.7}).wait(1).to({graphics:mask_1_graphics_234,x:512.6,y:365.7}).wait(1).to({graphics:mask_1_graphics_235,x:512.6,y:365.7}).wait(1).to({graphics:mask_1_graphics_236,x:512.6,y:365.7}).wait(1).to({graphics:mask_1_graphics_237,x:512.6,y:365.7}).wait(1).to({graphics:mask_1_graphics_238,x:512.6,y:365.7}).wait(1).to({graphics:mask_1_graphics_239,x:512.6,y:365.7}).wait(1).to({graphics:mask_1_graphics_240,x:512.6,y:365.7}).wait(1).to({graphics:mask_1_graphics_241,x:512.6,y:365.7}).wait(1).to({graphics:mask_1_graphics_242,x:512.6,y:365.7}).wait(1).to({graphics:mask_1_graphics_243,x:512.6,y:365.7}).wait(1).to({graphics:mask_1_graphics_244,x:512.6,y:365.7}).wait(1).to({graphics:mask_1_graphics_245,x:512.6,y:365.7}).wait(1).to({graphics:mask_1_graphics_246,x:512.6,y:365.7}).wait(1).to({graphics:mask_1_graphics_247,x:512.6,y:365.7}).wait(1).to({graphics:mask_1_graphics_248,x:512.6,y:365.7}).wait(1).to({graphics:mask_1_graphics_249,x:512.6,y:365.7}).wait(1).to({graphics:mask_1_graphics_250,x:512.6,y:365.7}).wait(1).to({graphics:mask_1_graphics_251,x:512.6,y:365.7}).wait(1).to({graphics:mask_1_graphics_252,x:512.6,y:365.7}).wait(1).to({graphics:mask_1_graphics_253,x:512.6,y:365.7}).wait(1).to({graphics:mask_1_graphics_254,x:512.6,y:365.7}).wait(1).to({graphics:mask_1_graphics_255,x:512.6,y:365.7}).wait(1).to({graphics:mask_1_graphics_256,x:512.6,y:365.7}).wait(1).to({graphics:mask_1_graphics_257,x:512.6,y:365.7}).wait(1).to({graphics:mask_1_graphics_258,x:512.6,y:365.7}).wait(1).to({graphics:mask_1_graphics_259,x:512.6,y:365.7}).wait(1).to({graphics:mask_1_graphics_260,x:512.6,y:365.7}).wait(1).to({graphics:mask_1_graphics_261,x:512.6,y:365.7}).wait(1).to({graphics:mask_1_graphics_262,x:512.6,y:365.7}).wait(1).to({graphics:mask_1_graphics_263,x:512.6,y:365.7}).wait(1).to({graphics:mask_1_graphics_264,x:512.6,y:365.7}).wait(1).to({graphics:mask_1_graphics_265,x:512.6,y:365.7}).wait(1).to({graphics:mask_1_graphics_266,x:512.6,y:365.7}).wait(1).to({graphics:mask_1_graphics_267,x:512.6,y:365.7}).wait(1).to({graphics:mask_1_graphics_268,x:512.6,y:365.7}).wait(1).to({graphics:mask_1_graphics_269,x:512.6,y:365.7}).wait(1).to({graphics:mask_1_graphics_270,x:512.6,y:365.7}).wait(1).to({graphics:mask_1_graphics_271,x:512.6,y:365.7}).wait(1).to({graphics:mask_1_graphics_272,x:512.6,y:365.7}).wait(1).to({graphics:mask_1_graphics_273,x:512.6,y:365.7}).wait(1).to({graphics:mask_1_graphics_274,x:512.6,y:365.7}).wait(1).to({graphics:mask_1_graphics_275,x:512.6,y:365.7}).wait(1).to({graphics:mask_1_graphics_276,x:512.6,y:365.7}).wait(1).to({graphics:mask_1_graphics_277,x:512.6,y:365.7}).wait(1).to({graphics:mask_1_graphics_278,x:512.6,y:365.7}).wait(1).to({graphics:mask_1_graphics_279,x:512.6,y:365.7}).wait(1).to({graphics:mask_1_graphics_280,x:512.6,y:365.7}).wait(1).to({graphics:mask_1_graphics_281,x:512.6,y:365.7}).wait(1).to({graphics:mask_1_graphics_282,x:512.6,y:365.7}).wait(1).to({graphics:mask_1_graphics_283,x:512.6,y:365.7}).wait(117));

	// Chimmy_obj_
	this.Chimmy = new lib.Scene_1_Chimmy();
	this.Chimmy.name = "Chimmy";
	this.Chimmy.setTransform(0.05,-0.05,1.5284,1.5284,0,0,0,269.1,1.4);
	this.Chimmy.depth = 0;
	this.Chimmy.isAttachedToCamera = 0
	this.Chimmy.isAttachedToMask = 0
	this.Chimmy.layerDepth = 0
	this.Chimmy.layerIndex = 13
	this.Chimmy.maskLayerName = 0

	var maskedShapeInstanceList = [this.Chimmy];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.Chimmy).wait(99).to({regX:0,regY:0,scaleX:1,scaleY:1,x:0,y:0},0).wait(184).to({_off:true},1).wait(116));

	// Grass_Darken_obj_
	this.Grass_Darken = new lib.Scene_1_Grass_Darken();
	this.Grass_Darken.name = "Grass_Darken";
	this.Grass_Darken.setTransform(0.05,-0.05,1.5284,1.5284,0,0,0,269.1,1.4);
	this.Grass_Darken.depth = 0;
	this.Grass_Darken.isAttachedToCamera = 0
	this.Grass_Darken.isAttachedToMask = 0
	this.Grass_Darken.layerDepth = 0
	this.Grass_Darken.layerIndex = 14
	this.Grass_Darken.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.Grass_Darken).wait(99).to({regX:0,regY:0,scaleX:1,scaleY:1,x:0,y:0},0).wait(100).to({_off:true},85).wait(116));

	// Grass_obj_
	this.Grass = new lib.Scene_1_Grass();
	this.Grass.name = "Grass";
	this.Grass.setTransform(0.05,-0.05,1.5284,1.5284,0,0,0,269.1,1.4);
	this.Grass.depth = 0;
	this.Grass.isAttachedToCamera = 0
	this.Grass.isAttachedToMask = 0
	this.Grass.layerDepth = 0
	this.Grass.layerIndex = 15
	this.Grass.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.Grass).wait(99).to({regX:0,regY:0,scaleX:1,scaleY:1,x:0,y:0},0).to({_off:true},100).wait(201));

	// Sky_Darken_obj_
	this.Sky_Darken = new lib.Scene_1_Sky_Darken();
	this.Sky_Darken.name = "Sky_Darken";
	this.Sky_Darken.setTransform(0.05,-0.05,1.5284,1.5284,0,0,0,269.1,1.4);
	this.Sky_Darken.depth = 0;
	this.Sky_Darken.isAttachedToCamera = 0
	this.Sky_Darken.isAttachedToMask = 0
	this.Sky_Darken.layerDepth = 0
	this.Sky_Darken.layerIndex = 16
	this.Sky_Darken.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.Sky_Darken).wait(99).to({regX:0,regY:0,scaleX:1,scaleY:1,x:0,y:0},0).wait(100).to({_off:true},85).wait(116));

	// Sky_obj_
	this.Sky = new lib.Scene_1_Sky();
	this.Sky.name = "Sky";
	this.Sky.setTransform(0.05,-0.05,1.5284,1.5284,0,0,0,269.1,1.4);
	this.Sky.depth = 0;
	this.Sky.isAttachedToCamera = 0
	this.Sky.isAttachedToMask = 0
	this.Sky.layerDepth = 0
	this.Sky.layerIndex = 17
	this.Sky.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.Sky).wait(99).to({regX:0,regY:0,scaleX:1,scaleY:1,x:0,y:0},0).to({_off:true},100).wait(201));

	this._renderFirstFrame();

}).prototype = p = new lib.AnMovieClip();
p.nominalBounds = new cjs.Rectangle(70.9,201.6,1060.1999999999998,359.19999999999993);
// library properties:
lib.properties = {
	id: '5C633F05269AEE43905F880C72CE5868',
	width: 800,
	height: 500,
	fps: 24,
	color: "#000000",
	opacity: 1.00,
	manifest: [
		{src:"images/ChimmyStockPhoto.png?1653898674306", id:"ChimmyStockPhoto"},
		{src:"images/join_atlas_1.png?1653898674202", id:"join_atlas_1"},
		{src:"images/join_atlas_2.png?1653898674202", id:"join_atlas_2"},
		{src:"sounds/ButtonSong.mp3?1653898674306", id:"ButtonSong"},
		{src:"components/lib/jquery-3.4.1.min.js?1653898674306", id:"lib/jquery-3.4.1.min.js"},
		{src:"components/sdk/anwidget.js?1653898674306", id:"sdk/anwidget.js"},
		{src:"components/video/src/video.js?1653898674306", id:"an.Video"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['5C633F05269AEE43905F880C72CE5868'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}

p._getProjectionMatrix = function(container, totalDepth) {	var focalLength = 528.25;
	var projectionCenter = { x : lib.properties.width/2, y : lib.properties.height/2 };
	var scale = (totalDepth + focalLength)/focalLength;
	var scaleMat = new createjs.Matrix2D;
	scaleMat.a = 1/scale;
	scaleMat.d = 1/scale;
	var projMat = new createjs.Matrix2D;
	projMat.tx = -projectionCenter.x;
	projMat.ty = -projectionCenter.y;
	projMat = projMat.prependMatrix(scaleMat);
	projMat.tx += projectionCenter.x;
	projMat.ty += projectionCenter.y;
	return projMat;
}
p._handleTick = function(event) {
	var cameraInstance = exportRoot.___camera___instance;
	if(cameraInstance !== undefined && cameraInstance.pinToObject !== undefined)
	{
		cameraInstance.x = cameraInstance.pinToObject.x + cameraInstance.pinToObject.pinOffsetX;
		cameraInstance.y = cameraInstance.pinToObject.y + cameraInstance.pinToObject.pinOffsetY;
		if(cameraInstance.pinToObject.parent !== undefined && cameraInstance.pinToObject.parent.depth !== undefined)
		cameraInstance.depth = cameraInstance.pinToObject.parent.depth + cameraInstance.pinToObject.pinOffsetZ;
	}
	stage._applyLayerZDepth(exportRoot);
}
p._applyLayerZDepth = function(parent)
{
	var cameraInstance = parent.___camera___instance;
	var focalLength = 528.25;
	var projectionCenter = { 'x' : 0, 'y' : 0};
	if(parent === exportRoot)
	{
		var stageCenter = { 'x' : lib.properties.width/2, 'y' : lib.properties.height/2 };
		projectionCenter.x = stageCenter.x;
		projectionCenter.y = stageCenter.y;
	}
	for(child in parent.children)
	{
		var layerObj = parent.children[child];
		if(layerObj == cameraInstance)
			continue;
		stage._applyLayerZDepth(layerObj, cameraInstance);
		if(layerObj.layerDepth === undefined)
			continue;
		if(layerObj.currentFrame != layerObj.parent.currentFrame)
		{
			layerObj.gotoAndPlay(layerObj.parent.currentFrame);
		}
		var matToApply = new createjs.Matrix2D;
		var cameraMat = new createjs.Matrix2D;
		var totalDepth = layerObj.layerDepth ? layerObj.layerDepth : 0;
		var cameraDepth = 0;
		if(cameraInstance && !layerObj.isAttachedToCamera)
		{
			var mat = cameraInstance.getMatrix();
			mat.tx -= projectionCenter.x;
			mat.ty -= projectionCenter.y;
			cameraMat = mat.invert();
			cameraMat.prependTransform(projectionCenter.x, projectionCenter.y, 1, 1, 0, 0, 0, 0, 0);
			cameraMat.appendTransform(-projectionCenter.x, -projectionCenter.y, 1, 1, 0, 0, 0, 0, 0);
			if(cameraInstance.depth)
				cameraDepth = cameraInstance.depth;
		}
		if(layerObj.depth)
		{
			totalDepth = layerObj.depth;
		}
		//Offset by camera depth
		totalDepth -= cameraDepth;
		if(totalDepth < -focalLength)
		{
			matToApply.a = 0;
			matToApply.d = 0;
		}
		else
		{
			if(layerObj.layerDepth)
			{
				var sizeLockedMat = stage._getProjectionMatrix(parent, layerObj.layerDepth);
				if(sizeLockedMat)
				{
					sizeLockedMat.invert();
					matToApply.prependMatrix(sizeLockedMat);
				}
			}
			matToApply.prependMatrix(cameraMat);
			var projMat = stage._getProjectionMatrix(parent, totalDepth);
			if(projMat)
			{
				matToApply.prependMatrix(projMat);
			}
		}
		layerObj.transformMatrix = matToApply;
	}
}
an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}

// Virtual camera API : 

an.VirtualCamera = new function() {
var _camera = new Object();
function VC(timeline) {
	this.timeline = timeline;
	this.camera = timeline.___camera___instance;
	this.centerX = lib.properties.width / 2;
	this.centerY = lib.properties.height / 2;
	this.camAxisX = this.camera.x;
	this.camAxisY = this.camera.y;
	if(timeline.___camera___instance == null || timeline.___camera___instance == undefined ) {
		timeline.___camera___instance = new cjs.MovieClip();
		timeline.___camera___instance.visible = false;
		timeline.___camera___instance.parent = timeline;
		timeline.___camera___instance.setTransform(this.centerX, this.centerY);
	}
	this.camera = timeline.___camera___instance;
}

VC.prototype.moveBy = function(x, y, z) {
z = typeof z !== 'undefined' ? z : 0;
	var position = this.___getCamPosition___();
	var rotAngle = this.getRotation()*Math.PI/180;
	var sinTheta = Math.sin(rotAngle);
	var cosTheta = Math.cos(rotAngle);
	var offX= x*cosTheta + y*sinTheta;
	var offY = y*cosTheta - x*sinTheta;
	this.camAxisX = this.camAxisX - x;
	this.camAxisY = this.camAxisY - y;
	var posX = position.x + offX;
	var posY = position.y + offY;
	this.camera.x = this.centerX - posX;
	this.camera.y = this.centerY - posY;
	this.camera.depth += z;
};

VC.prototype.setPosition = function(x, y, z) {
	z = typeof z !== 'undefined' ? z : 0;

	const MAX_X = 10000;
	const MIN_X = -10000;
	const MAX_Y = 10000;
	const MIN_Y = -10000;
	const MAX_Z = 10000;
	const MIN_Z = -5000;

	if(x > MAX_X)
	  x = MAX_X;
	else if(x < MIN_X)
	  x = MIN_X;
	if(y > MAX_Y)
	  y = MAX_Y;
	else if(y < MIN_Y)
	  y = MIN_Y;
	if(z > MAX_Z)
	  z = MAX_Z;
	else if(z < MIN_Z)
	  z = MIN_Z;

	var rotAngle = this.getRotation()*Math.PI/180;
	var sinTheta = Math.sin(rotAngle);
	var cosTheta = Math.cos(rotAngle);
	var offX= x*cosTheta + y*sinTheta;
	var offY = y*cosTheta - x*sinTheta;
	
	this.camAxisX = this.centerX - x;
	this.camAxisY = this.centerY - y;
	this.camera.x = this.centerX - offX;
	this.camera.y = this.centerY - offY;
	this.camera.depth = z;
};

VC.prototype.getPosition = function() {
	var loc = new Object();
	loc['x'] = this.centerX - this.camAxisX;
	loc['y'] = this.centerY - this.camAxisY;
	loc['z'] = this.camera.depth;
	return loc;
};

VC.prototype.resetPosition = function() {
	this.setPosition(0, 0);
};

VC.prototype.zoomBy = function(zoom) {
	this.setZoom( (this.getZoom() * zoom) / 100);
};

VC.prototype.setZoom = function(zoom) {
	const MAX_zoom = 10000;
	const MIN_zoom = 1;
	if(zoom > MAX_zoom)
	zoom = MAX_zoom;
	else if(zoom < MIN_zoom)
	zoom = MIN_zoom;
	this.camera.scaleX = 100 / zoom;
	this.camera.scaleY = 100 / zoom;
};

VC.prototype.getZoom = function() {
	return 100 / this.camera.scaleX;
};

VC.prototype.resetZoom = function() {
	this.setZoom(100);
};

VC.prototype.rotateBy = function(angle) {
	this.setRotation( this.getRotation() + angle );
};

VC.prototype.setRotation = function(angle) {
	const MAX_angle = 180;
	const MIN_angle = -179;
	if(angle > MAX_angle)
		angle = MAX_angle;
	else if(angle < MIN_angle)
		angle = MIN_angle;
	this.camera.rotation = -angle;
};

VC.prototype.getRotation = function() {
	return -this.camera.rotation;
};

VC.prototype.resetRotation = function() {
	this.setRotation(0);
};

VC.prototype.reset = function() {
	this.resetPosition();
	this.resetZoom();
	this.resetRotation();
	this.unpinCamera();
};
VC.prototype.setZDepth = function(zDepth) {
	const MAX_zDepth = 10000;
	const MIN_zDepth = -5000;
	if(zDepth > MAX_zDepth)
		zDepth = MAX_zDepth;
	else if(zDepth < MIN_zDepth)
		zDepth = MIN_zDepth;
	this.camera.depth = zDepth;
}
VC.prototype.getZDepth = function() {
	return this.camera.depth;
}
VC.prototype.resetZDepth = function() {
	this.camera.depth = 0;
}

VC.prototype.pinCameraToObject = function(obj, offsetX, offsetY, offsetZ) {

	offsetX = typeof offsetX !== 'undefined' ? offsetX : 0;

	offsetY = typeof offsetY !== 'undefined' ? offsetY : 0;

	offsetZ = typeof offsetZ !== 'undefined' ? offsetZ : 0;
	if(obj === undefined)
		return;
	this.camera.pinToObject = obj;
	this.camera.pinToObject.pinOffsetX = offsetX;
	this.camera.pinToObject.pinOffsetY = offsetY;
	this.camera.pinToObject.pinOffsetZ = offsetZ;
};

VC.prototype.setPinOffset = function(offsetX, offsetY, offsetZ) {
	if(this.camera.pinToObject != undefined) {
	this.camera.pinToObject.pinOffsetX = offsetX;
	this.camera.pinToObject.pinOffsetY = offsetY;
	this.camera.pinToObject.pinOffsetZ = offsetZ;
	}
};

VC.prototype.unpinCamera = function() {
	this.camera.pinToObject = undefined;
};
VC.prototype.___getCamPosition___ = function() {
	var loc = new Object();
	loc['x'] = this.centerX - this.camera.x;
	loc['y'] = this.centerY - this.camera.y;
	loc['z'] = this.depth;
	return loc;
};

this.getCamera = function(timeline) {
	timeline = typeof timeline !== 'undefined' ? timeline : null;
	if(timeline === null) timeline = exportRoot;
	if(_camera[timeline] == undefined)
	_camera[timeline] = new VC(timeline);
	return _camera[timeline];
}

this.getCameraAsMovieClip = function(timeline) {
	timeline = typeof timeline !== 'undefined' ? timeline : null;
	if(timeline === null) timeline = exportRoot;
	return this.getCamera(timeline).camera;
}
}


// Layer depth API : 

an.Layer = new function() {
	this.getLayerZDepth = function(timeline, layerName)
	{
		if(layerName === "Camera")
		layerName = "___camera___instance";
		var script = "if(timeline." + layerName + ") timeline." + layerName + ".depth; else 0;";
		return eval(script);
	}
	this.setLayerZDepth = function(timeline, layerName, zDepth)
	{
		const MAX_zDepth = 10000;
		const MIN_zDepth = -5000;
		if(zDepth > MAX_zDepth)
			zDepth = MAX_zDepth;
		else if(zDepth < MIN_zDepth)
			zDepth = MIN_zDepth;
		if(layerName === "Camera")
		layerName = "___camera___instance";
		var script = "if(timeline." + layerName + ") timeline." + layerName + ".depth = " + zDepth + ";";
		eval(script);
	}
	this.removeLayer = function(timeline, layerName)
	{
		if(layerName === "Camera")
		layerName = "___camera___instance";
		var script = "if(timeline." + layerName + ") timeline.removeChild(timeline." + layerName + ");";
		eval(script);
	}
	this.addNewLayer = function(timeline, layerName, zDepth)
	{
		if(layerName === "Camera")
		layerName = "___camera___instance";
		zDepth = typeof zDepth !== 'undefined' ? zDepth : 0;
		var layer = new createjs.MovieClip();
		layer.name = layerName;
		layer.depth = zDepth;
		layer.layerIndex = 0;
		timeline.addChild(layer);
	}
}
function _updateVisibility(evt) {
	var parent = this.parent;
	var detach = this.stage == null || this._off || !parent;
	while(parent) {
		if(parent.visible) {
			parent = parent.parent;
		}
		else{
			detach = true;
			break;
		}
	}
	detach = detach && this._element && this._element._attached;
	if(detach) {
		this._element.detach();
		this.dispatchEvent('detached');
		stage.removeEventListener('drawstart', this._updateVisibilityCbk);
		this._updateVisibilityCbk = false;
	}
}
function _handleDrawEnd(evt) {
	if(this._element && this._element._attached) {
		var props = this.getConcatenatedDisplayProps(this._props), mat = props.matrix;
		var tx1 = mat.decompose(); var sx = tx1.scaleX; var sy = tx1.scaleY;
		var dp = window.devicePixelRatio || 1; var w = this.nominalBounds.width * sx; var h = this.nominalBounds.height * sy;
		mat.tx/=dp;mat.ty/=dp; mat.a/=(dp*sx);mat.b/=(dp*sx);mat.c/=(dp*sy);mat.d/=(dp*sy);
		this._element.setProperty('transform-origin', this.regX + 'px ' + this.regY + 'px');
		var x = (mat.tx + this.regX*mat.a + this.regY*mat.c - this.regX);
		var y = (mat.ty + this.regX*mat.b + this.regY*mat.d - this.regY);
		var tx = 'matrix(' + mat.a + ',' + mat.b + ',' + mat.c + ',' + mat.d + ',' + x + ',' + y + ')';
		this._element.setProperty('transform', tx);
		this._element.setProperty('width', w);
		this._element.setProperty('height', h);
		this._element.update();
	}
}

function _tick(evt) {
	var stage = this.stage;
	stage&&stage.on('drawend', this._handleDrawEnd, this, true);
	if(!this._updateVisibilityCbk) {
		this._updateVisibilityCbk = stage.on('drawstart', this._updateVisibility, this, false);
	}
}
function _componentDraw(ctx) {
	if(this._element && !this._element._attached) {
		this._element.attach($('#dom_overlay_container'));
		this.dispatchEvent('attached');
	}
}
an.handleSoundStreamOnTick = function(event) {
	if(!event.paused){
		var stageChild = stage.getChildAt(0);
		if(!stageChild.paused || stageChild.ignorePause){
			stageChild.syncStreamSounds();
		}
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;